const APP_CONFIG = {
	APP_NAME: process.env.APP_NAME || 'Pappaya Sign',
	APP_BRAND_URL: process.env.APP_BRAND_URL,
	APP_MAIL_SENDER: process.env.APP_MAIL_SENDER || 'noreply@pappayasign.com',
};

module.exports = APP_CONFIG;
