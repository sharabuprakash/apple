import classnames from 'classnames';
import { fabric } from '@pappaya/fabric';
import $ from 'jquery';
import * as jsPDF from 'jspdf';
import React from 'react';
import {
	Button,
	Col,
	FormGroup,
	Input,
	Nav,
	NavItem,
	NavLink,
	Row,
	TabContent,
	TabPane,
} from 'reactstrap';
import DataVar from '../../variables/data';
import PreviewData from '../../variables/preview';
import './pdfannotate.css';
import './styles.css';
import Async from 'async';
import { getColorFromHex, randomString, getGeoInfo } from './utils';
import SignManager from '../SignManager';
import InitialManager from '../InitialManager';
import { SignCompleted } from 'components/Emails/SignCompleted';
import { SignReviewAndRequest } from 'components/Emails/SignReviewAndRequest';
import { VoidedEmail } from 'components/Emails/VoidedEmail';
import APP_CONFIG from '../../config';
import {getPngDimensions, mergeImages, resizeImage} from '../../utils/image';
import { generateInitial, isSignMode } from '../../utils/sign';
import ShortcutKeyList from '../ShortcutKeyList';
import { SHORTCUT_DEFINITION } from '../ShortcutKeyList/definition';
import addingFieldsImg from '../../utils/adding-fields.gif';
import {parseQueryString} from "../../utils/query-string";
import {resizeDimention} from "../../utils/dimention";

const axios = require('axios').default;
var PDFJS = require('pdfjs-dist');

// PDFJS.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.3.200/pdf.worker.min.js';
// PDFJS.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.3.200/pdf.worker.min.js';

//var fabric = require("fabric-webpack");
//var jsPDF = require("jspdf-react");
//const pdfjsWorker = require('pdfjs-dist/build/pdf.worker.entry')

/*
 *
 *  UTILITY
 *
 */
function hexToRgb(hex) {
	var result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
	return result
		? {
			r: parseInt(result[1], 16),
			g: parseInt(result[2], 16),
			b: parseInt(result[3], 16),
		}
		: null;
}

function setCookie(name, value, days) {
	var expires = '';
	if (days) {
		var date = new Date();
		date.setTime(date.getTime() + days * 24 * 60 * 60 * 1000);
		expires = '; expires=' + date.toUTCString();
	}
	document.cookie = name + '=' + (value || '') + expires + '; path=/';
}

function getCookie(name) {
	var nameEQ = name + '=';
	var ca = document.cookie.split(';');
	for (var i = 0; i < ca.length; i++) {
		var c = ca[i];
		while (c.charAt(0) == ' ') c = c.substring(1, c.length);
		if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length);
	}
	return null;
}

// function randomString(len, bits) {
//     bits = bits || 36;
//     var outStr = '',
//         newStr;
//     while (outStr.length < len) {
//         newStr = Math.random().toString(bits).slice(2);
//         outStr += newStr.slice(
//             0,
//             Math.min(newStr.length, len - outStr.length),
//         );
//     }
//     return outStr.toUpperCase();
// };

$.urlParam = function (name) {
	var results = new RegExp('[?&]' + name + '=([^&#]*)').exec(
		window.location.href,
	);
	if (results == null) {
		return null;
	}
	return decodeURI(results[1]) || 0;
};

const FABRICJS_PROPERTIES_TO_INCLUDED = ['id'];

/*
 *
 *  PDF Annotate Class
 *
 */
class PDFAnnotate extends React.Component {
	state = {
		tabs: 1,
		showSignModal: false,
		signType: '', //signature || initial
	};

	toggleSignModal = (signType = 'signature') => {
		const { showSignModal } = this.state;
		this.setState({
			showSignModal: !showSignModal,
			signType,
		});
	};

	openSite = (e) => {
		e.preventDefault();
		window.open(APP_CONFIG.BRAND_URL);
	};

	doubleclickobj = null;
	pdf = null;
	signimage = '';
	initialimage = '';
	clipboard = null;

	resizePDFContainerHandler = null;

	sendEmailBtnClickHandler = null;
	clearBtnClickHandler = null;
	deleteBtnClickHandler = null;
	downloaddocbtnClickHandler = null;
	printbtnClickHandler = null;
	onlysignerfinishbtnClickHandler = null;
	textbtnClickHandler = null;
	namebtnClickHandler = null;
	companyBtnClickHandler = null;
	titlebtnClickHandler = null;
	datebtnClickHandler = null;
	signaturebtnClickHandler = null;
	initialbtnClickHandler = null;
	boldbtnClickHandler = null;
	italicbtnClickHandler = null;
	underlinebtnClickHandler = null;
	startsigndocbtnClickHandler = null;
	recieverfinishbtnClickHandler = null;
	recieverfinishlaterbtnClickHandler = null;
	recieverdeclinebtnClickHandler = null;
	addfieldsbtnClickHandler = null;
	sendwithoutfieldsbtnClickHandler = null;
	zoominbtnClickHandler = null;
	zoomoutbtnClickHandler = null;
	backbtnClickHandler = null;
	mouseMoveHandler = null;

	saveSign = async (e) => {
		const { signType } = this.state;
		let image = null;

		if (APP_CONFIG.ENABLE_SIGN_BOX) {
			image = signType === 'signFature' ? e.signatureBox : e.initialsBox;
			if (e.signature) this.signimage = e.signatureBox;
			if (e.initials) this.initialimage = e.initialsBox;
		} else {
			image = signType === 'signature' ? e.signature : e.initials;
			if (e.signature) this.signimage = e.signature;
			if (e.initials) this.initialimage = e.initials;
		}

		if (image) {
			image = await resizeImage(
				image,
				null,
				this.doubleclickobj.get('height'),
			);
			this.doubleclickobj.setSrc(image);
			this.doubleclickobj.set('backgroundColor', 'transparent');
			this.pdf.Reload();
			this.toggleSignModal();
		} else {
			alert(`Please set your ${signType}!`);
		}
	};

	generatePdf = async function() {
        let doc = new jsPDF('p', 'pt', 'a4', true);
        let canvasTemp = document.createElement("canvas");
        const promises = this.pdf.fabricObjects.map((fabricObj, index) => {
            return new Promise(async resolve => {
                const bg = DataVar.Backgrounds[index];
                canvasTemp.width = bg.width;
                canvasTemp.height = bg.height;
                await fabricObj.setZoom(1);
                await fabricObj.renderAll(fabricObj)
                let mergedImages = await mergeImages([
                    bg.src,
                    await fabricObj.toDataURL('image/jpeg', 1)
                ], {
                    Canvas: canvasTemp,
                });

                console.log("merged", index);

                if (index !== 0) {
                    await doc.addPage();
                    await doc.setPage(index + 1);
                    console.log("add page", index);
                }

                console.log('add image', index)
                await doc.addImage(mergedImages, 'JPEG', 0, 0, undefined, undefined, undefined, 'FAST');
                let objectResponse = await fabricObj.toJSON(FABRICJS_PROPERTIES_TO_INCLUDED);
                objectResponse.backgroundImage = bg;
                resolve(JSON.stringify(objectResponse));
            })
        })

        const objectsWithBackground = await Promise.all(promises);

        return {
            doc,
            objects: objectsWithBackground
        };
    }

	componentWillUnmount() {
		$(document).off('click', '#sendemailbtn', this.sendEmailBtnClickHandler);
		$(document).off('click', '#clearbtn', this.clearBtnClickHandler);
		$(document).off('click', '#deletebtn', this.deleteBtnClickHandler);
		$(document).off('click', '#downloaddocbtn', this.downloaddocbtnClickHandler);
		$(document).off('click', '#printbtn', this.printbtnClickHandler);
		$(document).off('click', '#onlysignerfinishbtn', this.onlysignerfinishbtnClickHandler);
		$(document).off('click', '#textbtn', this.textbtnClickHandler);
		$(document).off('click', '#namebtn', this.namebtnClickHandler);
		$(document).off('click', '#companybtn', this.companyBtnClickHandler);
		$(document).off('click', '#titlebtn', this.titlebtnClickHandler);
		$(document).off('click', '#datebtn', this.datebtnClickHandler);
		$(document).off('click', '#signaturebtn', this.signaturebtnClickHandler);
		$(document).off('click', '#initialbtn', this.initialbtnClickHandler);
		$(document).off('click', '#boldbtnClickHandler', this.boldbtnClickHandler);
		$(document).off('click', '#italicbtnClickHandler', this.italicbtnClickHandler);
		$(document).off('click', '#underlinebtnClickHandler', this.underlinebtnClickHandler);
		$(document).off('click', '#startsigndocbtn', this.startsigndocbtnClickHandler);
		$(document).off('click', '#recieverfinishbtn', this.recieverfinishbtnClickHandler);
		$(document).off('click', '#recieverfinishlaterbtn', this.recieverfinishlaterbtnClickHandler);
		$(document).off('click', '#recieverdeclinebtn', this.recieverdeclinebtnClickHandler);
		$(document).off('click', '#addfieldsbtn', this.addfieldsbtnClickHandler);
		$(document).off('click', '#sendwithoutfieldsbtn', this.sendwithoutfieldsbtnClickHandler);
		$(document).off('click', '#zoominbtn', this.zoominbtnClickHandler);
		$(document).off('click', '#zoomoutbtn', this.zoomoutbtnClickHandler);
		$(document).off('click', '#backbtn', this.backbtnClickHandler);
		$(document).off('mousemove', this.mouseMoveHandler);
		$(document).off('dragover', this.mouseMoveHandler);

		$(window).off('resize', this.resizePDFContainerHandler)
	}

	async componentDidMount() {
		var global = this;
		var ip = '';

		axios
			.post('/api/getip', {})
			.then(function (response) {
				var remoteAddress = response.data;
				const array = remoteAddress.split(':');
				ip = array[array.length - 1];
			})
			.catch(function (error) {
				console.log(error);
			});

		var recents = [];
		var mainurl = document.location.hash;
		var url = document.location.hash;
		var fileid = '';
		var filename = '';
		var type = '';
		var userid = '';
		var email = '';
		var recipientemail = '';
		var recipientcolor = '';
		var useridother = '';
		var owner = '';
		var grabbedcolor = '';
		var recipientrgbval = '';
		var docname = '';
		var action = '';
		var signorderval = false;
		var dbpeople = [];
		var key = '';
		var username = '';
		var usertitle = '';
		var formattingobject = '';
		var formattingobjectbg = '';
		var ObjectArray = [];
		var ObjectArrayIndex = 0;
		var ObjectCursorIndex = 0;

		var PDFAnnotate = function (
			container_id,
			filename,
			options = {},
		) {
			this.active_tool = 1; // 1 - Free hand, 2 - Text, 3 - Arrow, 4 - Rectangle
			this.fabricObjects = [];
			this.fabricObjectsData = DataVar.Objects;
			this.color = '#000';
			this.borderColor = '#000000';
			this.borderSize = 1;
			this.font_size = 16;
			this.active_canvas = 0;
			this.container_id = container_id;
			this.imageurl = '';
			this.Addtext = 'Sample Text';
			this.recipientemail = '';
			this.recipientcolor = '';
			this.filename = filename;
			docname = filename;
			var inst = this;

			this.pageImages = [];
			this.orientation = 'p';
			this.pageSize = [595.28, 841.89]; // A4
			this.canvasScale = 1;

			this.initFabric = async function (fabricCallback) {
				var inst = this;

				console.log(DataVar.Backgrounds, DataVar.Objects);
				Async.eachOfSeries(DataVar.Objects, function (el, index, callback) {
				    const background = DataVar.Backgrounds[index];
                    const canvas = document.createElement('canvas');

                    let {width, height} = background;

                    if ($("#pdf-container").innerWidth() < background.width) {
                        let dimention = resizeDimention(background.width, background.height, $("#pdf-container").innerWidth())
                        width = dimention.width;
                        height = dimention.height;
                    }
                    console.log(width, height);

                    canvas.id = `page-${index}-canvas`;
                    canvas.class = 'canvas-container';
                    canvas.width = width;
                    canvas.height = height;
                    canvas.style.backgroundImage = 'url(' + background.src + ')';
                    canvas.style.backgroundSize = '100% auto';

                    if (isSignMode() && background.width !== width) {
                        inst.canvasScale = width / background.width;
                    }

                    if (inst.canvasScale > 1) inst.canvasScale = 1;

                    $('#pdf-container').append(canvas);

                    const thumbcanvas = document.createElement('div');
                    thumbcanvas.style.backgroundImage = 'url(' + background.src + ')';
                    thumbcanvas.className = 'thumb-pdf-canvas';
                    $("#thumb-pdf-container").append(thumbcanvas);

					var fabricObj = new fabric.Canvas(canvas.id, {
                        enableRetinaScaling: false,
						freeDrawingBrush: {
							width: 1,
							color: inst.color,
						},
						allowTouchScrolling: true,
					});

                    // var retina = fabricObj.getRetinaScaling();
                    // var ctx = canvas.getContext('2d');
                    // ctx.setTransform(retina, 0, 0, retina, 0, 0);

					fabricObj.on('object:selected', (e) => {
						e.target.transparentCorners = false;
						e.target.borderColor = '#cccccc';
						e.target.cornerColor = '#d35400';
						e.target.cornerStrokeColor = '#d35400';
						e.target.cornerSize = 8;
						e.target.cornerStyle = 'circle';
						e.target.minScaleLimit = 0;
						e.target.lockUniScaling = true;
						e.target.lockScalingFlip = true;
						e.target.hasRotatingPoint = false;
					});
					inst.fabricObjects.push(fabricObj);

					fabricObj.on('object:added', function () {
						inst.fabricObjectsData[index] = fabricObj.toJSON(FABRICJS_PROPERTIES_TO_INCLUDED);
					});

                    fabricObj.on('object:modified', function () {
                        inst.fabricObjectsData[index] = fabricObj.toJSON(FABRICJS_PROPERTIES_TO_INCLUDED);
                    });

                    fabricObj.on('object:removed', function () {
                        inst.fabricObjectsData[index] = fabricObj.toJSON(FABRICJS_PROPERTIES_TO_INCLUDED);
                    });

                    fabricObj.loadFromJSON(el, function () {
                        fabricObj.getObjects().forEach(function (targ) {
                                targ.selectable = false;
                                targ.hasControls = false;
                                targ.lockMovementX = true;
                                targ.lockMovementY = true;

                                if (targ.backgroundColor === recipientrgbval) {
                                    if (targ.type != 'text') {
                                        ObjectArray.push({ page: index, obj: targ });
                                        ObjectArray.sort((a, b) => a.page - b.page);
                                    }
                                } else {
                                    targ.hasBorders = false;
                                    targ.hoverCursor = 'auto';
                                }

                                if (targ.backgroundColor !== '' && targ.backgroundColor !== 'transparent' && targ.backgroundColor !== recipientrgbval && isSignMode()) {
                                    targ.visible = false;
                                } else {
                                    targ.visible = true;
                                }
                            },
                        );
                        fabricObj.renderAll(fabricObj);
                    });

                    fabricObj.upperCanvasEl.style.backgroundImage = "";

					// Scroll fix - Start
					var disableScroll = function () {
						fabricObj.allowTouchScrolling = false;
					};

					var enableScroll = function () {
						fabricObj.allowTouchScrolling = true;
					};

					fabricObj.on('selection:created', disableScroll);

					fabricObj.on('mouse:down', function (event) {
						if (event.target && event.target.asset) {
							disableScroll();
						} else {
							enableScroll();
						}
					});

					fabricObj.on('selection:cleared', enableScroll);
					// Scroll fix - End

					fabricObj.on({
						'mouse:up': function (e) {
							$('#dragabbleImageText').hide();
							$('#dragabbleImageSign').hide();
							$('#dragabbleImageInitial').hide();
							try {
								if (e.target) {
									//clicked on object
									const objcolor = e.target.backgroundColor;
									const objid = e.target.id;
									console.log("objid", objid);
									if (grabbedcolor != '') {
										var rgbval =
											hexToRgb(grabbedcolor).r +
											', ' +
											hexToRgb(grabbedcolor).g +
											', ' +
											hexToRgb(grabbedcolor).b;
										var RGB = 'rgb(' + rgbval + ')';
									} else {
										var RGB = '';
									}

									if (
										objcolor == RGB ||
										owner == 'admin' ||
										objid == email
									) {
										if (
											fabricObj.findTarget(e).type !=
											'text'
										) {
											if (
												fabricObj.findTarget(e).type !=
												'i-text'
											) {
												if (owner == 'admin') {
													formattingobject = fabricObj.findTarget(
														e,
													);
													document.getElementById(
														'formattingdiv',
													).style.display = 'block';
													document.getElementById(
														'fontdiv',
													).style.display = 'none';
													document.getElementById(
														'thumb-container',
													).style.display = 'none';
													document.getElementById(
														'input-scale-value',
													).value = '100';
													formattingobjectbg =
														e.target
															.backgroundColor;
													if (
														formattingobjectbg ===
														'transparent'
													) {
														$(
															'#requiredcheck',
														).prop(
															'checked',
															false,
														);
													}
													e.target.hasControls = true;
													e.target.lockMovementX = false;
													e.target.lockMovementY = false;
													fabricObj.requestRenderAll();

													document.getElementById(
														'input-pixels-left',
													).value = parseInt(
														e.target.left,
													);
													document.getElementById(
														'input-pixels-top',
													).value = parseInt(
														e.target.top,
													);
													var select = document.getElementById(
														'recipientselect',
													);
													var recipientname =
														select.options[
															select.selectedIndex
														].innerHTML;
													document.getElementById(
														'formattingrecipientname',
													).innerHTML =
														'Currently Selected:\n' +
														recipientname;
												}

												var id = fabricObj
													.getObjects()
													.indexOf(e.target);
												e.target.selectable = true;
												fabricObj.setActiveObject(
													fabricObj.item(id),
												);
												fabricObj.requestRenderAll();
											} else {
												//console.log('Object not selected');
												if (owner == 'admin') {
													formattingobject = fabricObj.findTarget(
														e,
													);
													document.getElementById(
														'formattingdiv',
													).style.display = 'block';
													document.getElementById(
														'fontdiv',
													).style.display = 'block';
													document.getElementById(
														'thumb-container',
													).style.display = 'none';
													document.getElementById(
														'input-scale-value',
													).value = '100';
													formattingobjectbg =
														e.target
															.backgroundColor;
													console.log(
														formattingobjectbg,
													);
													if (
														formattingobjectbg ===
														'transparent'
													) {
														$(
															'#requiredcheck',
														).prop(
															'checked',
															false,
														);
													}
													e.target.hasControls = true;
													e.target.lockMovementX = false;
													e.target.lockMovementY = false;
													fabricObj.requestRenderAll();

													document.getElementById(
														'input-pixels-left',
													).value = parseInt(
														e.target.left,
													);
													document.getElementById(
														'input-pixels-top',
													).value = parseInt(
														e.target.top,
													);
													var select = document.getElementById(
														'recipientselect',
													);
													var recipientname =
														select.options[
															select.selectedIndex
														].innerHTML;
													document.getElementById(
														'formattingrecipientname',
													).innerHTML =
														'Currently Selected:\n' +
														recipientname;
												}

												var id = fabricObj
													.getObjects()
													.indexOf(e.target);
												e.target.selectable = true;
												fabricObj.setActiveObject(
													fabricObj.item(id),
												);
												fabricObj.requestRenderAll();
											}
										}
									}
								} else {
									//add rectangle
									document.getElementById(
										'formattingdiv',
									).style.display = 'none';
									document.getElementById(
										'fontdiv',
									).style.display = 'none';
									document.getElementById(
										'thumb-container',
									).style.display = 'block';
									if (
										e.e.type == 'touchstart' ||
										e.e.type == 'touchmove' ||
										e.e.type == 'touchend' ||
										e.e.type == 'touchcancel'
									) {
										var x = e.pointer.x;
										var y = e.pointer.y;
										inst.active_canvas = index;
										fabricMouseHandler(e, fabricObj);
									} else if (
										e.e.type == 'mousedown' ||
										e.e.type == 'mouseup' ||
										e.e.type == 'mousemove' ||
										e.e.type == 'mouseover' ||
										e.e.type == 'mouseout' ||
										e.e.type == 'mouseenter' ||
										e.e.type == 'mouseleave'
									) {
										var x = e.e.clientX;
										var y = e.e.clientY;
										var click = e.e;
										inst.active_canvas = index;
										inst.fabricClickHandler(
											click,
											fabricObj,
										);
									}
								}
							} catch (error) { }
						},
					});

					const callbackEventDoubleClick = async function (e) {
						if (fabricObj.findTarget(e)) {
							const obj = fabricObj.findTarget(e);
							const objType = obj.type;
							const objcolor = obj.backgroundColor;
							const objid = obj.id;
							if (grabbedcolor != '') {
								var rgbval =
									hexToRgb(grabbedcolor).r +
									', ' +
									hexToRgb(grabbedcolor).g +
									', ' +
									hexToRgb(grabbedcolor).b;
								var RGB = 'rgb(' + rgbval + ')';
							}

							if (fabricObj.findTarget(e).type != 'text') {
								var id = fabricObj.getObjects().indexOf(obj);
								obj.selectable = true;
								fabricObj.setActiveObject(fabricObj.item(id));

								fabricObj.requestRenderAll();
								if (owner != 'admin') {
									if (isSignMode() && obj.id !== email) {
										return;
									}

									if (objType === 'image') {
										global.doubleclickobj = fabricObj.findTarget(
											e,
										);
										const signType = global.doubleclickobj.get(
											'signType',
										);
										if (
											obj.width === obj.height ||
											signType === 'initial'
										) {
											global.doubleclickobj.set(
												'signType',
												'initial',
											);
											if (
												global.initialimage != '' &&
												objcolor != 'transparent'
											) {
												global.doubleclickobj.setSrc(
													await resizeImage(
														global.initialimage,
														null,
														global.doubleclickobj.get(
															'height',
														),
													),
												);
												global.doubleclickobj.set(
													'backgroundColor',
													'transparent',
												);
												setTimeout(function () {
													fabricObj.requestRenderAll();
												}, 10);
												global.pdf.Reload();
												$('#movecursorbtn').html(
													'Next',
												);
											} else {
												global.toggleSignModal(
													'initial',
												);
												setTimeout(function () {
													fabricObj.requestRenderAll();
												}, 10);
												$('#movecursorbtn').html(
													'Next',
												);
											}
										} else {
											global.doubleclickobj.set(
												'signType',
												'signature',
											);
											if (
												global.signimage != '' &&
												objcolor != 'transparent'
											) {
												global.doubleclickobj.setSrc(
													await resizeImage(
														global.signimage,
														null,
														global.doubleclickobj.get(
															'height',
														),
													),
												);
												global.doubleclickobj.set(
													'backgroundColor',
													'transparent',
												);

												setTimeout(function () {
													fabricObj.requestRenderAll();
												}, 10);
												global.pdf.Reload();
												$('#movecursorbtn').html(
													'Next',
												);
											} else {
												global.toggleSignModal();
												setTimeout(function () {
													fabricObj.requestRenderAll();
												}, 10);
												$('#movecursorbtn').html(
													'Next',
												);
											}
										}
									} else if (objType === 'i-text') {
										$('#movecursorbtn').html('Next');
										if (username != '') {
											if (obj.text === 'Name') {
												obj.set('text', username);
												setTimeout(function () {
													fabricObj.requestRenderAll();
												}, 10);
											} else if (obj.text === 'Title') {
												obj.set('text', usertitle);
												setTimeout(function () {
													fabricObj.requestRenderAll();
												}, 10);
											} else if (
												obj.text === 'Date Signed'
											) {
												var today = new Date();
												var dd = String(
													today.getDate(),
												).padStart(2, '0');
												var mm = String(
													today.getMonth() + 1,
												).padStart(2, '0'); //January is 0!
												var yyyy = today.getFullYear();

												today =
													mm + '/' + dd + '/' + yyyy;
												obj.set('text', today);
												setTimeout(function () {
													fabricObj.requestRenderAll();
												}, 10);
											}
										} else {
											if (obj.text === 'Date Signed') {
												var today = new Date();
												var dd = String(
													today.getDate(),
												).padStart(2, '0');
												var mm = String(
													today.getMonth() + 1,
												).padStart(2, '0'); //January is 0!
												var yyyy = today.getFullYear();

												today =
													mm + '/' + dd + '/' + yyyy;
												obj.set('text', today);
												setTimeout(function () {
													fabricObj.requestRenderAll();
												}, 10);
											}
										}
										obj.set(
											'backgroundColor',
											'transparent',
										);
										global.pdf.Reload();

										var count = 0;
										$.each(inst.fabricObjects, function (
											index,
											fabricObj,
										) {
											fabricObj
												.getObjects()
												.forEach(function (targ) {
													targ.selectable = false;
													targ.hasControls = false;
													if (
														targ.backgroundColor ===
														recipientrgbval
													) {
														count = count + 1;
													}
												});
										});
										if (count === 0) {
											ObjectCursorIndex = 0;
											ObjectArrayIndex = 0;
											$("#movecursorbtn").hide();
											var page =
												ObjectArray[ObjectArrayIndex]
													.page;
											var nextobj =
												ObjectArray[ObjectArrayIndex]
													.obj;
											$('.upper-canvas')[
												ObjectArray[ObjectArrayIndex]
													.page
											].scrollIntoView({
												behavior: 'auto',
											});
										} else {
											$('#movecursorbtn').html('Next');
										}
									}
								} else if (owner == 'admin') {
									obj.lockMovementX = false;
									obj.lockMovementY = false;
									obj.hasControls = true;
									fabricObj.requestRenderAll();
									if (
										objcolor == 'transparent' ||
										objcolor == 'rgb(189, 189, 189)'
									) {
										if (objType === 'image') {
											global.doubleclickobj = fabricObj.findTarget(
												e,
											);
											if (obj.width === obj.height) {
												if (
													global.initialimage != '' &&
													objcolor != 'transparent'
												) {
													global.doubleclickobj.setSrc(
														global.initialimage,
													);
													global.doubleclickobj.set(
														'backgroundColor',
														'transparent',
													);
													global.doubleclickobj.set({
														width: 60,
														height: 20,
														scaleX: 0.6,
														scaleY: 0.6,
													});
													setTimeout(function () {
														fabricObj.requestRenderAll();
													}, 10);
													global.pdf.Reload();
												} else {
													global.toggleSignModal(
														'initial',
													);
													setTimeout(function () {
														fabricObj.requestRenderAll();
													}, 10);
													//global.doubleclickobj.set({ width: 60, height: 20, scaleX: 0.6, scaleY: 0.6, });
												}
											} else {
												if (
													global.signimage != '' &&
													objcolor != 'transparent'
												) {
													global.doubleclickobj.setSrc(
														global.signimage,
													);
													global.doubleclickobj.set(
														'backgroundColor',
														'transparent',
													);
													global.doubleclickobj.set({
														width: 60,
														height: 20,
														scaleX: 0.6,
														scaleY: 0.6,
													});
													setTimeout(function () {
														fabricObj.requestRenderAll();
													}, 10);
													global.pdf.Reload();
												} else {
													global.toggleSignModal();
													setTimeout(function () {
														fabricObj.requestRenderAll();
													}, 10);
													//global.doubleclickobj.set({ width: 60, height: 20, scaleX: 0.6, scaleY: 0.6, });
												}
											}
										} else if (objType === 'i-text') {
											if (username != '') {
												if (obj.text === 'Name') {
													obj.set('text', username);
													setTimeout(function () {
														fabricObj.requestRenderAll();
													}, 10);
												} else if (
													obj.text === 'Title'
												) {
													obj.set('text', usertitle);
													setTimeout(function () {
														fabricObj.requestRenderAll();
													}, 10);
												} else if (
													obj.text === 'Date Signed'
												) {
													var today = new Date()
														.toLocaleString()
														.replace(',', '');
													obj.set('text', today);
													setTimeout(function () {
														fabricObj.requestRenderAll();
													}, 10);
												}
											}
											obj.set(
												'backgroundColor',
												'transparent',
											);
											global.pdf.Reload();
										}
									}
								}
							}
						}
					};

					fabric.util.addListener(
						fabricObj.upperCanvasEl,
						'touchend',
						callbackEventDoubleClick,
					);

					fabric.util.addListener(
						fabricObj.upperCanvasEl,
						'dblclick',
						callbackEventDoubleClick,
					);

                    fabricObj.setZoom(inst.canvasScale);

					callback();
				}, function () {
                    setTimeout(() => {
                        $("#prepareLoadingModal").hide();
                    }, 1000)
                    fabricCallback();
				})

			};

            this.initFabric(function () {
                global.resizePDFContainerHandler();
            });

			async function fabricMouseHandler(e, fabricObj) {
				$('.tool.active').removeClass('active');
				$('.icon-color').removeClass('icon-color');
				if (inst.active_tool == 2) {
					var value = inst.Addtext;
					var text = new fabric.IText(value, {
						fontFamily: 'Arial',
						left:
							e.pointer.x -
							fabricObj.upperCanvasEl.getBoundingClientRect()
								.left -
							50,
						top:
							e.pointer.y -
							fabricObj.upperCanvasEl.getBoundingClientRect()
								.top -
							30,
						fill: inst.color,
						backgroundColor: inst.recipientcolor,
						id: inst.recipientemail,
						fontSize: inst.font_size,
						selectable: false,
						lockMovementX: true,
						lockMovementY: true,
						hasControls: false,
					});
					fabricObj.add(text);
					inst.active_tool = 0;

					$('.icon-color').removeClass('icon-color');
				} else if (inst.active_tool == 4) {
					var myImg = inst.imageurl;
					myImg = await resizeImage(
						myImg,
						null,
						inst.image_type === 1 ? 75 : 60,
					);
					fabric.Image.fromURL(
						myImg,
						(oImg) => {
							var l =
								e.pointer.x -
								fabricObj.upperCanvasEl.getBoundingClientRect()
									.left -
								(inst.image_type === 1 ? 150 : 60);
							var t =
								e.pointer.y -
								fabricObj.upperCanvasEl.getBoundingClientRect()
									.top -
								(inst.image_type === 1 ? 75 : 60);
							oImg.set({ left: l });
							oImg.set({ top: t });
							oImg.set({ id: inst.recipientemail });
							oImg.set({ selectable: false });
							oImg.set({ lockMovementX: true });
							oImg.set({ lockMovementY: true });
							oImg.set({ hasControls: false });
							oImg.set({ backgroundColor: inst.recipientcolor });
							fabricObj.add(oImg);

							inst.image_type = -1;
						},
						{ crossOrigin: 'Anonymous' },
					);
					inst.active_tool = 0;
					$('.tool-button.active').removeClass('active');
					$('.icon-color').removeClass('icon-color');
				} else if (inst.active_tool == 5) {
					var rect = new fabric.Rect({
						left:
							e.pointer.x -
							fabricObj.upperCanvasEl.getBoundingClientRect()
								.left,
						top:
							e.pointer.y -
							fabricObj.upperCanvasEl.getBoundingClientRect()
								.top +
							250,
						width: 100,
						height: 100,
						fill: 'rgba(0,0,0,0)',
						stroke: inst.color,
						id: inst.recipientemail,
						selectable: false,
						strokeSize: inst.borderSize,
					});
					fabricObj.add(rect);

					inst.active_tool = 0;
					$('.icon-color').removeClass('icon-color');
				} else if (inst.active_tool == 6) {
					var circle = new fabric.Circle({
						left:
							e.pointer.x -
							fabricObj.upperCanvasEl.getBoundingClientRect()
								.left,
						top:
							e.pointer.y -
							fabricObj.upperCanvasEl.getBoundingClientRect()
								.top +
							250,
						radius: 50,
						fill: 'rgba(0,0,0,0)',
						stroke: inst.color,
						id: inst.recipientemail,
						selectable: false,
						strokeSize: inst.borderSize,
					});
					fabricObj.add(circle);

					inst.active_tool = 0;
					$('.icon-color').removeClass('icon-color');
				}
			}

			this.fabricClickHandler = async function (event, fabricObj) {
				var inst = this;
				$('.tool.active').removeClass('active');
				$('.icon-color').removeClass('icon-color');

				if (inst.active_tool == 2) {
					var value = inst.Addtext;
					var text = new fabric.IText(value, {
						fontFamily: 'Arial',
						left:
							event.clientX -
							fabricObj.upperCanvasEl.getBoundingClientRect()
								.left -
							50,
						top:
							event.clientY -
							fabricObj.upperCanvasEl.getBoundingClientRect()
								.top -
							30,
						fill: inst.color,
						backgroundColor: inst.recipientcolor,
						id: inst.recipientemail,
						fontSize: inst.font_size,
						selectable: false,
						lockMovementX: true,
						lockMovementY: true,
						hasControls: false,
					});
					fabricObj.add(text);
					inst.active_tool = 0;

					$('.icon-color').removeClass('icon-color');
				} else if (inst.active_tool == 4) {
					var myImg = inst.imageurl;
					myImg = await resizeImage(
						myImg,
						null,
						inst.image_type === 1 ? 75 : 60,
					);
					let offsetY = 0;
					let offsetX = 0;
					if (inst.image_type === 1) {
						offsetY = 75;
						offsetX = 150;
					} else {
						offsetY = 60;
						offsetX = 60;
					}

					fabric.Image.fromURL(
						myImg,
						(oImg) => {
							var l =
								event.clientX -
								fabricObj.upperCanvasEl.getBoundingClientRect()
									.left -
								offsetX;
							var t =
								event.clientY -
								fabricObj.upperCanvasEl.getBoundingClientRect()
									.top -
								offsetY;

							oImg.set({ left: l });
							oImg.set({ top: t });
							oImg.set({ id: inst.recipientemail });
							oImg.set({ selectable: false });
							oImg.set({ lockMovementX: true });
							oImg.set({ lockMovementY: true });
							oImg.set({ hasControls: false });
							oImg.set({ backgroundColor: inst.recipientcolor });
							fabricObj.add(oImg);

							inst.image_type = -1;
						},
						{ crossOrigin: 'Anonymous' },
					);
					inst.active_tool = 0;
					$('.tool-button.active').removeClass('active');
					$('.icon-color').removeClass('icon-color');
				} else if (inst.active_tool == 5) {
					var rect = new fabric.Rect({
						left:
							event.clientX -
							fabricObj.upperCanvasEl.getBoundingClientRect()
								.left -
							100,
						top:
							event.clientY -
							fabricObj.upperCanvasEl.getBoundingClientRect()
								.top -
							20,
						width: 100,
						height: 100,
						fill: 'rgba(0,0,0,0)',
						stroke: inst.color,
						id: inst.recipientemail,
						strokeSize: inst.borderSize,
						selectable: false,
					});
					fabricObj.add(rect);

					inst.active_tool = 0;
					$('.icon-color').removeClass('icon-color');
				} else if (inst.active_tool == 6) {
					var circle = new fabric.Circle({
						left:
							event.clientX -
							fabricObj.upperCanvasEl.getBoundingClientRect()
								.left -
							100,
						top:
							event.clientY -
							fabricObj.upperCanvasEl.getBoundingClientRect()
								.top -
							20,
						radius: 50,
						fill: 'rgba(0,0,0,0)',
						stroke: inst.color,
						id: inst.recipientemail,
						strokeSize: inst.borderSize,
						selectable: false,
					});
					fabricObj.add(circle);

					inst.active_tool = 0;
					$('.icon-color').removeClass('icon-color');
				}
			};

			$('#pdf-container').css('z-index', '0');
			$('#container').css('z-index', '0');
			$('.canvas').css('z-index', '0');

			$('#movecursorbtn').click(function () {
				var pageHeight = $('#pdf-container .canvas-container').height() + 25; //25 is margin

				if (ObjectCursorIndex === ObjectArray.length) {
					var count = 0;
					ObjectCursorIndex = 0;
					ObjectArrayIndex = 0;
					$.each(inst.fabricObjects, function (index, fabricObj) {
						fabricObj.getObjects().forEach(function (targ) {
							targ.selectable = false;
							targ.hasControls = false;
							if (targ.backgroundColor === recipientrgbval) {
								count = count + 1;
							}
						});
					});
					if (count === 0) {
					    $("#movecursorbtn").hide();
						var recieverfinishbtn = document.getElementById(
							'recieverfinishbtn',
						);
						recieverfinishbtn.scrollIntoView();
					} else {
						var page = ObjectArray[ObjectArrayIndex].page;
						var nextobj = ObjectArray[ObjectArrayIndex].obj;
						if (nextobj.type === 'i-text') {
							$('#movecursorbtn').html('Add');
						} else {
							$('#movecursorbtn').html('Next');
						}
						global.pdf.Reload();
						inst.fabricObjects[page].setActiveObject(nextobj);
						$('.upper-canvas')[
							ObjectArray[ObjectArrayIndex].page
						].scrollIntoView({ behavior: 'auto' });
						$('#movecursorbtn').css({
							top: page * pageHeight + nextobj.top * inst.canvasScale + 10,
						});
						ObjectCursorIndex = ObjectCursorIndex + 1;
					}
				} else if (ObjectCursorIndex < ObjectArray.length) {
                    var page = ObjectArray[ObjectArrayIndex].page;
                    var nextobj = ObjectArray[ObjectArrayIndex].obj;
                    if (nextobj.type === 'i-text') {
                        $('#movecursorbtn').html('Add');
                    } else {
                        $('#movecursorbtn').html('Next');
                    }
                    global.pdf.Reload();
                    inst.fabricObjects[page].setActiveObject(nextobj);
                    $('.upper-canvas')[
                        ObjectArray[ObjectArrayIndex].page
                        ].scrollIntoView({ behavior: 'auto' });
                    $('#movecursorbtn').css({
                        top: page * pageHeight + nextobj.top * inst.canvasScale + 10,
                    });
                    $('#container').animate({
                            scrollTop: page * pageHeight + nextobj.top * inst.canvasScale + 10,
                        }, 1000,
                    );
                    ObjectCursorIndex = ObjectCursorIndex + 1;
				}
			});
		};

		PDFAnnotate.prototype.enableSelector = function () {
			var inst = this;
			inst.active_tool = 0;
			if (inst.fabricObjects.length > 0) {
				$.each(inst.fabricObjects, function (index, fabricObj) {
					fabricObj.isDrawingMode = false;
				});
			}
		};

		PDFAnnotate.prototype.enablePencil = function () {
			var inst = this;
			inst.active_tool = 1;
			if (inst.fabricObjects.length > 0) {
				$.each(inst.fabricObjects, function (index, fabricObj) {
					fabricObj.isDrawingMode = true;
				});
			}
		};

		PDFAnnotate.prototype.enableAddText = function (
			text,
			recipientemail,
			recipientcolor,
		) {
			var inst = this;
			inst.Addtext = text;
			inst.recipientemail = recipientemail;
			inst.recipientcolor = recipientcolor;
			inst.active_tool = 2;
			if (inst.fabricObjects.length > 0) {
				$.each(inst.fabricObjects, function (index, fabricObj) {
					fabricObj.isDrawingMode = false;
				});
			}
		};

		PDFAnnotate.prototype.enableImage = function (
			url,
			recipientemail,
			recipientcolor,
			scale,
			image_type = -1, // 1 for sign and 2 for initial
		) {
			var inst = this;
			inst.recipientemail = recipientemail;
			inst.recipientcolor = recipientcolor;
			inst.image_type = image_type;
			inst.active_tool = 4;
			inst.imageurl = url;
			if (inst.fabricObjects.length > 0) {
				$.each(inst.fabricObjects, function (index, fabricObj) {
					fabricObj.isDrawingMode = false;
				});
			}
		};

		PDFAnnotate.prototype.enableRectangle = function () {
			var inst = this;
			var fabricObj = inst.fabricObjects[inst.active_canvas];
			inst.active_tool = 5;
			if (inst.fabricObjects.length > 0) {
				$.each(inst.fabricObjects, function (index, fabricObj) {
					fabricObj.isDrawingMode = false;
				});
			}
		};

		PDFAnnotate.prototype.enableCircle = function () {
			var inst = this;
			var fabricObj = inst.fabricObjects[inst.active_canvas];
			inst.active_tool = 6;
			if (inst.fabricObjects.length > 0) {
				$.each(inst.fabricObjects, function (index, fabricObj) {
					fabricObj.isDrawingMode = false;
				});
			}
		};

		PDFAnnotate.prototype.deleteSelectedObject = function () {
			var inst = this;
			var activeObject = inst.fabricObjects[
				inst.active_canvas
			].getActiveObject();
			if (activeObject) {
				inst.fabricObjects[inst.active_canvas].remove(activeObject);
				document.getElementById('formattingdiv').style.display = 'none';
				document.getElementById('fontdiv').style.display = 'none';
				document.getElementById('thumb-container').style.display =
					'block';
			}
		};

		PDFAnnotate.prototype.ZoomIn = function () {
			var inst = this;

			var container = document.getElementById(inst.container_id);
			var scaleX =
				container.getBoundingClientRect().width / container.offsetWidth;
			scaleX = scaleX + 0.1;
			container.style.transform = 'scale(' + scaleX + ')';
		};

		PDFAnnotate.prototype.ZoomOut = function () {
			var inst = this;

			var container = document.getElementById(inst.container_id);
			var scaleX =
				container.getBoundingClientRect().width / container.offsetWidth;
			scaleX = scaleX - 0.1;
			container.style.transform = 'scale(' + scaleX + ')';
		};

		this.resizePDFContainerHandler = function () {
			let container = document.getElementById('pdf-container');
			const canvases = document.querySelectorAll(`.canvas-container`);

			if (!container) return;

			if (canvases.length > 0) {
				let scaleX = container.offsetWidth / canvases[0].offsetWidth;
				if (scaleX > 1) {
					scaleX = 1;
				}

				container.style.transform = 'scale(' + scaleX + ')';
				container.scrollTo(0, 0);
			}
		};

		$(window).on('resize', this.resizePDFContainerHandler)

		PDFAnnotate.prototype.savePdf = async function () {
			let {doc} = await global.generatePdf();
			doc.save(`[${APP_CONFIG.APP_NAME}] ${global.pdf.filename}.pdf`);
			$("#saveLoadingModal").hide();
		};

		PDFAnnotate.prototype.printPdf = async function () {
            let {doc} = await global.generatePdf();
            $("#saveLoadingModal").hide();
			window.open(doc.output('bloburl'), '_blank');
		};

		PDFAnnotate.prototype.DownloadIndividual = function (fabricindex) {
			var inst = this;
			var fabricObj = inst.fabricObjects[fabricindex];
			var doc = new jsPDF(inst.orientation, 'pt', inst.pageSize, true);
			doc.addImage(
				fabricObj.toDataURL('image/png', 1),
				'PNG',
				0,
				0,
				undefined,
				undefined,
				undefined,
				'FAST',
			);
			doc.save(`[${APP_CONFIG.APP_NAME}] ${fabricindex}.pdf`);
			$("#saveLoadingModal").hide();
		};

		PDFAnnotate.prototype.checkallupdated = function () {
			var inst = this;
			var count = 0;
			if (useridother == '') {
				global.pdf.savetoCloudPdf();
			} else if (userid == useridother) {
				global.pdf.savetoCloudPdf();
			} else if (userid != useridother) {
				$.each(inst.fabricObjects, function (index, fabricObj) {
					fabricObj.getObjects().forEach(function (targ) {
						targ.selectable = false;
						targ.hasControls = false;
						if (targ.backgroundColor === recipientrgbval) {
							count = count + 1;
						}
					});
				});
				if (count === 0) {
					global.pdf.savetoCloudPdf();
				} else {
					alert('Please add all details to continue');
					$("#saveLoadingModal").hide();
				}
			}
		};

		PDFAnnotate.prototype.OnlySignerSave = async function () {
			var inst = this;
			var today = new Date().toLocaleString().replace(',', '');

			if (
				action === '' ||
				action === 'correct' ||
				typeof action === 'undefined'
			) {
				if (useridother == '') {
					if (fileid === '') {
						filename = randomString(13);
					} else {
						filename = fileid;
					}

                    const {doc, objects} = await global.generatePdf();

                    var dataURI = doc.output('datauristring');

                    if (recents.length >= 5) {
                        var removefirst = recents.shift();
                    }

                    recents.push({
                        DocumentName: inst.filename,
                        DocumentID: filename,
                        Status: 'Completed',
                        Timestamp: today,
                    });
                    var recents_str = JSON.stringify(recents);

                    setCookie('recents', recents_str, 10);

                    axios
                        .post('/api/adddocumentdata', {
                            DocumentName: inst.filename,
                            DocumentID: filename,
                            OwnerEmail: email,
                            DateCreated: today,
                            DateStatus: today,
                            DateSent: '',
                            Owner: userid,
                            Status: 'Completed',
                            SignOrder: DataVar.SignOrder,
                            Data: objects,
                            Reciever: [],
                        })
                        .then(function (response) {
                            if (
                                response.data === 'insert done' ||
                                response.data === 'update done'
                            ) {
                                var Reciever = [
                                    {
                                        RecipientName: email,
                                        DocumentName: inst.filename,
                                        RecipientEmail: email,
                                        RecipientColor: '#bdbdbd',
                                        RecipientOption:
                                            'Need to Sign',
                                        RecipientStatus:
                                            'Completed',
                                        RecipientDateStatus: today,
                                    },
                                ];
                                axios
                                    .post('/api/addreciever', {
                                        Status: 'Completed',
                                        DocumentID: filename,
                                        SignOrder: false,
                                        DateSent: today,
                                        Reciever: Reciever,
                                        Owner: userid,
                                    })
                                    .then(function (response) {})
                                    .catch(function (error) {
                                        console.log(error);
                                        alert(error);
                                    });
                                axios
                                    .post('/api/posthistory', {
                                        DocumentID: filename,
                                        HistoryTime: today,
                                        HistoryUser:
                                            email +
                                            '\n[' +
                                            ip +
                                            ']',
                                        HistoryAction: 'Registered',
                                        HistoryActivity:
                                            'The envelope was created by ' +
                                            email +
                                            '',
                                        HistoryStatus: 'Created',
                                        Owner: userid,
                                    })
                                    .then(function (response) { })
                                    .catch(function (error) {
                                        console.log(error);
                                    });

                                axios
                                    .post('/api/postrequest', {
                                        UserID: userid,
                                        DocumentName: inst.filename,
                                        DocumentID: filename,
                                        From: userid,
                                        FromEmail: email,
                                        RecipientStatus:
                                            'Completed',
                                        RecipientDateStatus: today,
                                    })
                                    .then(function (response) {})
                                    .catch(function (error) {
                                        console.log(error);
                                        alert(error);
                                    });

                                axios
                                    .post('/api/posthistory', {
                                        DocumentID: filename,
                                        HistoryTime: today,
                                        HistoryUser:
                                            email +
                                            '\n[' +
                                            ip +
                                            ']',
                                        HistoryAction: 'Signed',
                                        HistoryActivity:
                                            '' +
                                            email +
                                            ' signed the envelope',
                                        HistoryStatus: 'Completed',
                                        Owner: userid,
                                    })
                                    .then(function (response) {})
                                    .catch(function (error) {
                                        console.log(error);
                                    });
                                var url =
                                    process.env.REACT_APP_BASE_URL +
                                    '/#/admin/sign?id=' +
                                    fileid +
                                    '&type=db&u=' +
                                    userid +
                                    '&key=0';
                                axios
                                    .post(
                                        '/api/sendmailattachments',
                                        {
                                            to: email,
                                            body: SignCompleted({
                                                DocumentName:
                                                    inst.filename +
                                                    '.pdf',
                                            }),
                                            subject: `${APP_CONFIG.APP_NAME}: Completed ${inst.filename}`,
                                            attachments: {
                                                filename: `[${APP_CONFIG.APP_NAME}] Completed ${inst.filename}.pdf`,
                                                path: dataURI,
                                            },
                                        },
                                    )
                                    .then(function (response) {})
                                    .catch(function (error) {
                                        alert(
                                            'Error, Please try again later',
                                        );
                                        $("#saveLoadingModal").hide();
                                    });

                                DataVar.Objects = [];
                                window.location.hash =
                                    '#/admin/completesuccess';
                                url =
                                    process.env.REACT_APP_BASE_URL +
                                    '/#/admin/sign?id=' +
                                    encodeURIComponent(filename) +
                                    '&type=db&u=' +
                                    userid;
                                $("#saveLoadingModal").hide();
                            }
                        })
                        .catch(function (error) {
                            console.log(error);
                            $("#saveLoadingModal").hide();
                        });
				}
			}
		};

		PDFAnnotate.prototype.savetoCloudPdf = async function () {
			var inst = this;

			var today = new Date().toLocaleString().replace(',', '');
			if (
				action === '' ||
				action === 'correct' ||
				typeof action === 'undefined'
			) {
				if (useridother == '') {
					if (fileid === '') {
						filename = randomString(13);
					} else {
						filename = fileid;
					}

					try {
					    let { objects } = await global.generatePdf();
                        if (recents.length >= 5) {
                            var removefirst = recents.shift();
                        }
                        recents.push({
                            DocumentName: inst.filename,
                            DocumentID: filename,
                            Status: 'Draft',
                            Timestamp: today,
                        });
                        var recents_str = JSON.stringify(recents);
                        setCookie('recents', recents_str, 10);

                        const addDocDataResponse = await axios
                            .post('/api/adddocumentdata', {
                                DocumentName: inst.filename,
                                DocumentID: filename,
                                OwnerEmail: email,
                                DateCreated: today,
                                DateStatus: today,
                                DateSent: '',
                                Owner: userid,
                                Status: 'Draft',
                                SignOrder: DataVar.SignOrder,
                                Data: objects,
                                Reciever: [],
                            });

                        if (addDocDataResponse.data === 'insert done' || addDocDataResponse.data === 'update done') {
                            await axios
                                .post('/api/posthistory', {
                                    DocumentID: filename,
                                    HistoryTime: today,
                                    HistoryUser: email + '\n[' + ip + ']',
                                    HistoryAction: 'Registered',
                                    HistoryActivity: `The envelope was created by ${email}`,
                                    HistoryStatus: 'Created',
                                    Owner: userid,
                                })

                            document.getElementById(
                                'emailbtncontainer',
                            ).style.display = 'block';
                            url =
                                process.env.REACT_APP_BASE_URL +
                                '/#/admin/sign?id=' +
                                encodeURIComponent(filename) +
                                '&type=db&u=' +
                                userid;
                        }
					} catch (e) {
						console.log(e);
					}
					$("#saveLoadingModal").hide();
				} else {
					var completedcount = 0;
					var recievercount = 0;
					const { objects, doc } = await global.generatePdf();
					var documentname = docname;

					console.log('prepare updatedocumentdata');
					await axios
						.post('/api/updatedocumentdata', {
							DocumentID: filename,
							DateStatus: today,
							Data: objects,
							Owner: useridother,
						})
						.then(async function (response) {
						    console.log(response.data);
							if (response.data === 'insert done' || response.data === 'update done') {
								await axios
									.post('/api/posthistory', {
										DocumentID: filename,
										HistoryTime: today,
										HistoryUser: email + '\n[' + ip + ']',
										HistoryAction: 'Signed',
										HistoryActivity:
											'' + email + ' signed the envelope',
										HistoryStatus: 'Completed',
										Owner: useridother,
									});
								var recipientkey = '';
								completedcount = 0;

								const response = await axios
                                    .post('/api/getReciever', {
                                        DocumentID: filename,
                                        Owner: useridother,
                                    })

                                var recievers = response.data.Reciever;
                                var OwnerEmail = response.data.OwnerEmail;
                                recievercount = recievers.length;
                                recievers.forEach(async function (item, index,) {
                                    documentname = recievers[0].DocumentName;

                                    if (recievers[index].RecipientEmail === email) {
                                        recipientkey = index;

                                        recievers[index].RecipientStatus = 'Completed';
                                        recievers[index].RecipientDateStatus = today;

                                        axios.post(
                                            '/api/updaterecieverdata',
                                            {
                                                Reciever: recievers,
                                                DocumentID: filename,
                                                Owner: useridother,
                                            },
                                        )
                                            .then(async function (response,) {
                                                if (response.data === 'update reciever done') {
                                                    const getRequest = await axios
                                                        .post('/api/getRequests', { UserID: userid,},)
                                                    if (getRequest.data.Status === 'got request') {
                                                        var request = getRequest.data.Request;

                                                        const promises = request.map(
                                                            async function (item, index,) {
                                                                if (request[index].DocumentID === filename) {
                                                                    request[index].RecipientStatus = 'Completed';
                                                                    request[index].RecipientDateStatus = today;

                                                                    return new Promise(async resolve => {
                                                                        await axios.post('/api/updaterequestdata',
                                                                            { UserID: userid,  Request: request,},)
                                                                        resolve();
                                                                    })
                                                                }
                                                            },
                                                        );

                                                        await Promise.all(promises);
                                                    }
                                                }
                                            })
                                            .catch(function (
                                                error,
                                            ) {
                                                console.log(error);
                                                alert('Error, Please try again later',);
                                                $("#saveLoadingModal").hide();
                                            });

                                        if (signorderval === true) {
                                            try {
                                                var nextuser = recievers.findIndex((_, i) => i > recipientkey && _.RecipientOption === 'Needs to Sign',
                                                );
                                                var currentuser = parseInt(recipientkey,);
                                                var nextuseremail = recievers[nextuser].RecipientEmail;
                                                var nextusername = recievers[nextuser].RecipientName;

                                                if (currentuser === recievercount) {
                                                    console.log('no additional users left');
                                                } else if (currentuser < recievercount) {
                                                    try {
                                                        var nextuserurl =
                                                            process
                                                                .env
                                                                .REACT_APP_BASE_URL +
                                                            '/#/admin/sign?id=' +
                                                            filename +
                                                            '&type=db&u=' +
                                                            useridother +
                                                            '&key=' +
                                                            nextuser +
                                                            '';

                                                        axios.post('/api/getrequestuser', { UserEmail: nextuseremail,},
                                                        )
                                                            .then(function (response,) {
                                                                    if (response.data.Status === 'user found') {
                                                                        axios.post('/api/postrequest', {
                                                                                UserID: response.data.UserID,
                                                                                DocumentName: documentname,
                                                                                DocumentID: filename,
                                                                                From: useridother,
                                                                                FromEmail: OwnerEmail,
                                                                                RecipientStatus:
                                                                                    'Need to Sign',
                                                                                RecipientDateStatus: today,
                                                                            },
                                                                        )
                                                                    }
                                                                },
                                                            )

                                                        axios
                                                            .post(
                                                                '/api/sendmail',
                                                                {
                                                                    from: global.doc.Owner
                                                                        ? `${global.doc.Owner.UserFirstName} ${global.doc.Owner.UserLastName}`
                                                                        : null,
                                                                    to: nextuseremail,
                                                                    body: SignReviewAndRequest(
                                                                        {
                                                                            RecipientName: nextusername,
                                                                            DocumentName: documentname,
                                                                            URL: nextuserurl,
                                                                        },
                                                                    ),
                                                                    subject: `${APP_CONFIG.APP_NAME}: Please Sign ${documentname}`,
                                                                },
                                                            )
                                                            .then(function (response,) {
                                                                    window.location.hash = '#/admin/completesuccess';
                                                                },
                                                            )
                                                    } catch (error) { }
                                                }
                                            } catch (error) { }
                                        }
                                    }
                                });

                                let needToSignCount = recievers.filter((_) => _.RecipientOption === 'Needs to Sign',).length;
                                let finishedSignCount = recievers.filter(
                                    (_) =>
                                        (_.RecipientStatus ===
                                            'Completed' &&
                                            _.RecipientOption ===
                                            'Needs to Sign') ||
                                        _.RecipientEmail === email,
                                ).length;

                                if (needToSignCount === finishedSignCount) {
                                    var dataURI = doc.output('datauristring',);

                                    await axios
                                        .post('/api/posthistory', {
                                            DocumentID: filename,
                                            HistoryTime: today,
                                            HistoryUser:
                                                email +
                                                '\n[' +
                                                ip +
                                                ']',
                                            HistoryAction:
                                                'Printable Copy Delivered',
                                            HistoryActivity:
                                                '' +
                                                email +
                                                ' received a printable copy of the envelope',
                                            HistoryStatus:
                                                'Completed',
                                            Owner: useridother,
                                        })

                                    await axios
                                        .post(
                                            '/api/sendmailattachments',
                                            {
                                                to: OwnerEmail,
                                                body: SignCompleted(
                                                    {
                                                        DocumentName: documentname,
                                                    },
                                                ),
                                                subject: `${APP_CONFIG.APP_NAME}: Completed ${documentname}`,
                                                attachments: {
                                                    filename: `[${APP_CONFIG.APP_NAME}] Completed ${documentname}.pdf`,
                                                    path: dataURI,
                                                },
                                            },
                                        )

                                    const recieversPromises = recievers.map((_) => {
                                        return new Promise(async resolve => {
                                            await axios
                                                .post(
                                                    '/api/sendmailattachments',
                                                    {
                                                        to:
                                                        _.RecipientEmail,
                                                        body: SignCompleted(
                                                            {
                                                                DocumentName: documentname,
                                                            },
                                                        ),
                                                        subject: `${APP_CONFIG.APP_NAME}: Completed ${documentname}`,
                                                        attachments: {
                                                            filename: `[${APP_CONFIG.APP_NAME}] Completed ${documentname}.pdf`,
                                                            path: dataURI,
                                                        },
                                                    },
                                                )
                                            resolve();
                                        })
                                    });

                                    await Promise.all(recieversPromises)

                                    axios
                                        .post(
                                            '/api/updatedocumentstatus',
                                            {
                                                DocumentID: filename,
                                                Status: 'Completed',
                                                Owner: useridother,
                                            },
                                        )
                                        .then(function (response) {
                                            if (response.data === 'insert done' || response.data === 'update done') {
                                                window.location.hash =
                                                    '#/admin/completesuccess';
                                            }
                                        })
                                        .catch(function (error) {
                                            console.log(error);
                                            alert(
                                                'Error, Please try again later',
                                            );
                                            $("#saveLoadingModal").hide();
                                        });
                                }
                                $("#saveLoadingModal").hide();
                                window.location.hash =
                                    '#/admin/completesuccess';
							}
						})
						.catch(function (error) {
							console.log(error);
							$("#saveLoadingModal").hide();
						});
				}
			} else if (action === 'create') {
				filename = randomString(13);
                const {objects} = await global.generatePdf();

                axios
                    .post('/api/adddocumentdata', {
                        DocumentName: inst.filename,
                        DocumentID: filename,
                        OwnerEmail: email,
                        DateCreated: today,
                        DateStatus: today,
                        DateSent: '',
                        Owner: userid,
                        Status: 'Draft',
                        SignOrder: DataVar.SignOrder,
                        Data: objects,
                        Reciever: [],
                    })
                    .then(function (response) {
                        if (
                            response.data === 'insert done' ||
                            response.data === 'update done'
                        ) {
                            document.getElementById(
                                'emailbtncontainer',
                            ).style.display = 'block';
                            url =
                                process.env.REACT_APP_BASE_URL +
                                '/#/admin/sign?id=' +
                                encodeURIComponent(filename) +
                                '&type=db&u=' +
                                userid;
                            $("#saveLoadingModal").hide();
                        }
                    })
                    .catch(function (error) {
                        console.log(error);
                        $("#saveLoadingModal").hide();
                    });
			}
		};

		PDFAnnotate.prototype.setBrushSize = function (size) {
			var inst = this;
			$.each(inst.fabricObjects, function (index, fabricObj) {
				fabricObj.freeDrawingBrush.width = size;
			});
		};

		PDFAnnotate.prototype.setColor = function (color) {
			var inst = this;
			inst.color = color;
			$.each(inst.fabricObjects, function (index, fabricObj) {
				fabricObj.freeDrawingBrush.color = color;
			});
		};

		PDFAnnotate.prototype.setBorderColor = function (color) {
			var inst = this;
			inst.borderColor = color;
		};

		PDFAnnotate.prototype.setFontSize = function (size) {
			this.font_size = size;
		};

		PDFAnnotate.prototype.setBorderSize = function (size) {
			this.borderSize = size;
		};

		PDFAnnotate.prototype.clearActivePage = function () {
			var inst = this;
			$.each(inst.fabricObjects, function (index, fabricObj) {
				fabricObj.clear();
			});
		};

		PDFAnnotate.prototype.Reload = function () {
			var inst = this;
			$.each(inst.fabricObjects, function (index, fabricObj) {
				setTimeout(function () {
					fabricObj.requestRenderAll();
				}, 10);
			});
		};

		var pdf;
		var image_type = -1; // 1 for sign and 2 for initial

		$('#recipientselect').on('change', function () {
			var select = document.getElementById('recipientselect');
			recipientcolor =
				select.options[select.selectedIndex].style.backgroundColor;
			if (recipientcolor != 'rgb(189, 189, 189)') {
				document.getElementById(
					'dragabbleImageSign',
				).style.backgroundColor = recipientcolor;
				document.getElementById(
					'dragabbleImageText',
				).style.backgroundColor = recipientcolor;

				document.getElementById(
					'dragabbleImageInitial',
				).style.backgroundColor = recipientcolor;

				var elements = document.getElementsByClassName('tool');
				for (var i = 0; i < elements.length; i++) {
					elements[i].style.backgroundColor = recipientcolor;
				}
			} else {
				var elements = document.getElementsByClassName('tool');
				for (var i = 0; i < elements.length; i++) {
					elements[i].style.backgroundColor = 'transparent';
				}

				document.getElementById(
					'dragabbleImageSign',
				).style.backgroundColor = recipientcolor;
				document.getElementById(
					'dragabbleImageText',
				).style.backgroundColor = recipientcolor;
				document.getElementById(
					'dragabbleImageInitial',
				).style.backgroundColor = recipientcolor;
			}
		});

		global.mouseMoveHandler = function (e) {
			$('#dragabbleImageSign').css({
				left: e.clientX - 150,
				top: e.clientY - 75,
			});
			$('#dragabbleImageInitial').css({
				left: e.clientX - 60,
				top: e.clientY - 60,
			});
			$('#dragabbleImageText').css({
				left: e.clientX - 100,
				top: e.clientY - 30,
			});
		}

		$(document).on('mousemove', global.mouseMoveHandler)
		$(document).on('dragover', global.mouseMoveHandler)

		$('#dragabbleImageSign').hide();
		$('#dragabbleImageText').hide();
		$('#dragabbleImageInitial').hide();

		try {
			var people = [];
			people = DataVar.RecipientArray;
			if (people.length == 1) {
				if (people[0].email != email) {
					recipientcolor = '#E6EE9C';
				}
			} else {
				recipientcolor = '#bdbdbd';
			}
		} catch (error) {
			recipientcolor = '#bdbdbd';
		}

		if (DataVar.OnlySigner) {
			document.getElementById(
				'emailbtncontainer',
			).style.display = 'none';
		}

		document.getElementById(
			'dragabbleImageSign',
		).style.backgroundColor = recipientcolor;
		document.getElementById(
			'dragabbleImageText',
		).style.backgroundColor = recipientcolor;

		document.getElementById(
			'dragabbleImageInitial',
		).style.backgroundColor = recipientcolor;

		global.zoominbtnClickHandler = function () {
			global.pdf.ZoomIn();
		}

		$(document).on('click', '#zoominbtn', global.zoominbtnClickHandler);

		global.zoomoutbtnClickHandler = function () {
			global.pdf.ZoomOut();
		}

		$(document).on('click', '#zoomoutbtn', global.zoomoutbtnClickHandler);

		global.clearBtnClickHandler = function (event) {
			$('.tool.active').removeClass('active');
			$('.icon-color').removeClass('icon-color');
			try {
				global.pdf.clearActivePage();
			} catch (error) {
				alert('Please add a document first!');
				$('.tool-button.active').removeClass('active');
				$('.icon-color').removeClass('icon-color');
			}
		}

		$(document).on("click", "#clearbtn", global.clearBtnClickHandler)

		global.deleteBtnClickHandler = function (event) {
			$('.tool.active').removeClass('active');
			$('.icon-color').removeClass('icon-color');
			try {
				global.pdf.deleteSelectedObject();
			} catch (error) {
				alert('Please add a document first!');
				$('.tool-button.active').removeClass('active');
				$('.icon-color').removeClass('icon-color');
			}
		}

		$(document).on("click", "#deletebtn", global.deleteBtnClickHandler);

		global.downloaddocbtnClickHandler = function (event) {
			$('.tool.active').removeClass('active');
			$('.icon-color').removeClass('icon-color');
			$("#saveLoadingModal").show();
			try {
                global.pdf.savePdf();
			} catch (error) {
				alert('Please add a document first!');
				$('.tool-button.active').removeClass('active');
				$('.icon-color').removeClass('icon-color');
			}
		}

		$(document).on("click", "#downloaddocbtn", global.downloaddocbtnClickHandler);

		global.printbtnClickHandler = function (event) {
			$('.tool.active').removeClass('active');
			$('.icon-color').removeClass('icon-color');
			$("#saveLoadingModal").show();
			try {
			    global.pdf.printPdf();
			} catch (error) {
				alert('Please add a document first!');
				$('.tool-button.active').removeClass('active');
				$('.icon-color').removeClass('icon-color');
			}
		}

		$(document).on("click", "#printbtn", global.printbtnClickHandler);

		global.textbtnClickHandler = function (event) {
			var element = $(event.target).hasClass('tool')
				? $(event.target)
				: $(event.target).parents('.tool').first();
			$('.tool.active').removeClass('active');
			$('.icon-color').removeClass('icon-color');
			$(element).addClass('active');
			const icon = this.querySelector('i');
			icon.classList.add('icon-color');
			var select = document.getElementById('recipientselect');
			recipientemail = select.options[select.selectedIndex].value;
			recipientcolor =
				select.options[select.selectedIndex].style.backgroundColor;

			try {
				if (recipientcolor == 'rgb(189, 189, 189)') {
					global.pdf.enableAddText(
						'Text',
						recipientemail,
						'transparent',
					);
				} else {
					global.pdf.enableAddText(
						'Text',
						recipientemail,
						recipientcolor,
					);
				}

				$('#dragabbleImageText').show();
				$('#dragabbleImageText').css(
					'z-index',
					'9999999999999999999999999999999999999999999',
				);
			} catch (error) {
				alert('Please add a document first!');
				$('#dragabbleImageText').hide();
				$('.tool-button.active').removeClass('active');
				$('.icon-color').removeClass('icon-color');
			}
		}

		$(document).on("click", "#textbtn", global.textbtnClickHandler)

		global.namebtnClickHandler = function (event) {
			var element = $(event.target).hasClass('tool')
				? $(event.target)
				: $(event.target).parents('.tool').first();
			$('.tool.active').removeClass('active');
			$('.icon-color').removeClass('icon-color');
			$(element).addClass('active');
			const icon = this.querySelector('i');
			icon.classList.add('icon-color');
			var select = document.getElementById('recipientselect');
			recipientemail = select.options[select.selectedIndex].value;
			recipientcolor =
				select.options[select.selectedIndex].style.backgroundColor;
			try {
				if (recipientcolor == 'rgb(189, 189, 189)') {
					if (username == '' || username == null) {
						global.pdf.enableAddText(
							'Name',
							recipientemail,
							'transparent',
						);
					} else {
						global.pdf.enableAddText(
							username,
							recipientemail,
							'transparent',
						);
					}
				} else {
					global.pdf.enableAddText(
						'Name',
						recipientemail,
						recipientcolor,
					);
				}

				$('#dragabbleImageText').show();
				$('#dragabbleImageText').css(
					'z-index',
					'9999999999999999999999999999999999999999999',
				);
			} catch (error) {
				alert('Please add a document first!');
				$('#dragabbleImageText').hide();
				$('.tool-button.active').removeClass('active');
				$('.icon-color').removeClass('icon-color');
			}
		}

		$(document).on("click", "#namebtn", global.namebtnClickHandler);

		global.companyBtnClickHandler = function (event) {
			var element = $(event.target).hasClass('tool')
				? $(event.target)
				: $(event.target).parents('.tool').first();
			$('.tool.active').removeClass('active');
			$('.icon-color').removeClass('icon-color');
			$(element).addClass('active');
			const icon = this.querySelector('i');
			icon.classList.add('icon-color');
			var select = document.getElementById('recipientselect');
			recipientemail = select.options[select.selectedIndex].value;
			recipientcolor =
				select.options[select.selectedIndex].style.backgroundColor;
			try {
				if (recipientcolor == 'rgb(189, 189, 189)') {
					global.pdf.enableAddText(
						'Company',
						recipientemail,
						'transparent',
					);
				} else {
					global.pdf.enableAddText(
						'Company',
						recipientemail,
						recipientcolor,
					);
				}
				$('#dragabbleImageText').show();
				$('#dragabbleImageText').css(
					'z-index',
					'9999999999999999999999999999999999999999999',
				);
			} catch (error) {
				alert('Please add a document first!');
				$('#dragabbleImageText').hide();
				$('.tool-button.active').removeClass('active');
				$('.icon-color').removeClass('icon-color');
			}
		}

		$(document).on("click", "#companybtn", global.companyBtnClickHandler)

		global.titlebtnClickHandler = function (event) {
			var element = $(event.target).hasClass('tool')
				? $(event.target)
				: $(event.target).parents('.tool').first();
			$('.tool.active').removeClass('active');
			$('.icon-color').removeClass('icon-color');
			$(element).addClass('active');
			const icon = this.querySelector('i');
			icon.classList.add('icon-color');
			var select = document.getElementById('recipientselect');
			recipientemail = select.options[select.selectedIndex].value;
			recipientcolor =
				select.options[select.selectedIndex].style.backgroundColor;
			try {
				if (recipientcolor == 'rgb(189, 189, 189)') {
					if (usertitle == '' || usertitle == null) {
						global.pdf.enableAddText(
							'Title',
							recipientemail,
							'transparent',
						);
					} else {
						global.pdf.enableAddText(
							usertitle,
							recipientemail,
							'transparent',
						);
					}
				} else {
					global.pdf.enableAddText(
						'Title',
						recipientemail,
						recipientcolor,
					);
				}
				$('#dragabbleImageText').show();
				$('#dragabbleImageText').css(
					'z-index',
					'9999999999999999999999999999999999999999999',
				);
			} catch (error) {
				alert('Please add a document first!');
				$('#dragabbleImageText').hide();
				$('.tool-button.active').removeClass('active');
				$('.icon-color').removeClass('icon-color');
			}
		};

		$(document).on("click", "#titlebtn", global.titlebtnClickHandler)

		global.datebtnClickHandler = function (event) {
			var element = $(event.target).hasClass('tool')
				? $(event.target)
				: $(event.target).parents('.tool').first();
			$('.tool.active').removeClass('active');
			$('.icon-color').removeClass('icon-color');
			$(element).addClass('active');
			const icon = this.querySelector('i');
			icon.classList.add('icon-color');
			var select = document.getElementById('recipientselect');
			recipientemail = select.options[select.selectedIndex].value;
			recipientcolor =
				select.options[select.selectedIndex].style.backgroundColor;
			var today = new Date();
			var dd = String(today.getDate()).padStart(2, '0');
			var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
			var yyyy = today.getFullYear();

			today = mm + '/' + dd + '/' + yyyy;

			try {
				if (recipientcolor == 'rgb(189, 189, 189)') {
					global.pdf.enableAddText(
						today,
						recipientemail,
						'transparent',
					);
				} else {
					global.pdf.enableAddText(
						'Date Signed',
						recipientemail,
						recipientcolor,
					);
				}
				$('#dragabbleImageText').show();
				$('#dragabbleImageText').css(
					'z-index',
					'9999999999999999999999999999999999999999999',
				);
			} catch (error) {
				alert('Please add a document first!');
				$('#dragabbleImageText').hide();
				$('.tool-button.active').removeClass('active');
				$('.icon-color').removeClass('icon-color');
			}
		}

		$(document).on('click', '#datebtn', global.datebtnClickHandler)

		global.signaturebtnClickHandler = function (event) {
			var element = $(event.target).hasClass('tool')
				? $(event.target)
				: $(event.target).parents('.tool').first();
			$('.tool.active').removeClass('active');
			$('.icon-color').removeClass('icon-color');
			$(element).addClass('active');
			const icon = this.querySelector('i');
			icon.classList.add('icon-color');
			var select = document.getElementById('recipientselect');
			recipientemail = select.options[select.selectedIndex].value;
			recipientcolor =
				select.options[select.selectedIndex].style.backgroundColor;
			var dataUrl = require('../../assets/img/icons/common/sign-here.png');
			try {
				$('#dragabbleImageSign').show();
				$('#dragabbleImageSign').css(
					'z-index',
					'9999999999999999999999999999999999999999999',
				);
				if (recipientcolor == 'rgb(189, 189, 189)') {
					if (global.signimage == '' || global.signimage == null) {
						global.pdf.enableImage(
							dataUrl,
							recipientemail,
							recipientcolor,
							0.7,
							1,
						);
					} else {
						global.pdf.enableImage(
							global.signimage,
							recipientemail,
							'transparent',
							0.6,
							1,
						);
					}
				} else {
					global.pdf.enableImage(
						dataUrl,
						recipientemail,
						recipientcolor,
						0.7,
						1,
					);
				}
			} catch (error) {
				alert('Add a Document');
				$('#dragabbleImageSign').hide();
			}
		}

		$(document).on("click", "#signaturebtn", global.signaturebtnClickHandler)

		global.initialbtnClickHandler = function (event) {
			var element = $(event.target).hasClass('tool')
				? $(event.target)
				: $(event.target).parents('.tool').first();
			$('.tool.active').removeClass('active');
			$('.icon-color').removeClass('icon-color');
			$(element).addClass('active');
			const icon = this.querySelector('i');
			icon.classList.add('icon-color');
			var select = document.getElementById('recipientselect');
			recipientemail = select.options[select.selectedIndex].value;
			recipientcolor =
				select.options[select.selectedIndex].style.backgroundColor;
			var dataUrl =
				'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADICAYAAACtWK6eAAAACXBIWXMAAC4jAAAuIwF4pT92AAAAIGNIUk0AAHolAACAgwAA+f8AAIDpAAB1MAAA6mAAADqYAAAXb5JfxUYAAAwUSURBVHja7J3BiyVHHce/bxxhMJJ5SsQ9RGYCChECeYEIOQgzorJCDrOSgwcPM7KHICtkgt4ziwcPHnb2L9g3sJ6iZPbmQdlZ9CBEyCxeFhLIW7KyAUHf4OomZrPtoWvY3pfu6uru6qru9z4faNid7tdV3V3f+v1+9auuHiRJIgDIZ4lbAIBAAGqxPPuHwWBQ9hvfPtnA8TjKpVxv5bqGFsv0EbCIZAxBkiOegU0gSYNeAIAYBACBAECtGCSWu0W5lIsFAUAgAAgEAIEAIBAABAIACAQAgQAgEAAEAoBAABAIAAIBQCAACwOv3MKiM8CCQC/o4hpty1UVBdCmIPL+5rDSDi4WLK6lOD0+hlBwsaA3blSSJMHdMAQCvYsxQooEgUAQYfhu1KFEgkAA4SEQCMznJC2FihnaLINRLPDJE0rTBPeTJHk4DxeEQMCnN/KxpE+TCBm/JEnqDgNb16LGxYImDCR93rhTD2OJo01XazB70sFgwOruEN33b9Soq1mSyp8/AOilMNryGwGchdEHcfisIwIBrAYCAcSBQABxeK83QfoC9pguozyLbDUQiIcG1JBNSdcL9n1D0ns8BVysReY1y74LsfuHebEePq6DRGF41iW9a7HeU0lfk3QvVqc5L/OoHL0Ba6IQCxKeCyWu7VDSdqS6rSidiQtYkGgN8K4RgY1bkr4ZybrdSZLkARYECxKD8w7ikKRnJb0cqY6f8pgI0mPxs5aO9cU/kzkb3216OQgkHGeNZXDlBxWP98F/5i6GaDhkj0DiW48jSRNLQB+ShzwmgvQYfF3p0G4eOyY43svZd0/pkO+0T24JQTpUpcgS3JP0O0kHBfu/qHhDvnDaW2Q3o6jZDeozlPTvgvt6JXPc9YJj3lfgKUGzbaLPW9Prx4K0z7axBHlkLce44Jh1BR7yjblYdNeuIy8GoUn75V0Tg8wykfTMjDt1t0BMf5D0feKQMALJXjsWpF1eLhCHJF3NiUcOC479nqTnsCLh649A2sWW7MsLzMc1An1E0ma9fQQ1kMtzBUF3IulPlt99UPCb+5Ke6sJAzjwG5gTp4bH1+OMa+1aUzuXqd4/cs7oSpLfD0ATcKzn7PpL0FRW/72FLKt4xgX2U2bZd9zB8tV2C9PY5XyAOSfqt7C9DvSfpzwX7npa0FbMBLlwHSgzinWWlyb2i+OOswzlerRm/RG1DsWOWNjSBQPyzZWncH8gtKz40QXnReUZ963g7LI7P3F+C9Hb5hWXfVcf4YarinIgk/bzr4pibQQTmYnllZOn1E1V7v+Os5Tz3JZ3BenjxerAgAbEN7f5F6bvmrvzRjFrlEW3Id+HAgnjjqZK44dUa5/yV5Xx31dGF/7AgkIdtaPcjpe99VOU3ln1nJL1C/DEIq3YsSC2WTY9e1Nu/2eDcb1vO+zbWo3mVbRYEgfjhRyXBeZvbSwgEF6vr7EYs+zXcqxbLYNGGxrwY2dV5oHRhhw8RSG0LMnsdLNowRz34suKvCD+3YEGacUbpvKuVyPX4UOks348itqOg5sOje4UFaZELHRDHqVB/HLH83qwIX1XHWJD6rBjr0ZUpH8eSXojl5oVeEd7VghQJIvN7qwXhE2z1eaVEHLck/dRzmW+peHX4kaRvq/hdklbaqWlDD7smDm8eH3mQ2tgSeElLgfOvS8p8M/A9WDKdxFKXch8Vz0GisAVeKmmo9+X2HZCqPFtS7idK3zoMxZclrXVJIDXOQaKwBcrex7iqdhacvqV0EbnCWEBhhp1PfZwnFe9biu25VbhYjXja9NS2nvzFlmMfW9n/Ussja6adPCnpW6asQWzr0eA8WBDPlH2E869ma4trsmfNh2phRfhsozJB8ieS/i7pfyFzIHlFtVo8FqQSK5L+UdKDh3iR6Zcldfib73bR5UXh2oxjEEg1zsd2byq4ed+dJ2HkNe4Qgf5SQQA2u0FK2Yc1ryrMdI87kn7fsK5hXRVfowMmBxKqrqysCL0Rx2n79FFXWztnZUXopThi1BWBIA5uAgIBxIFAAHEgEAAEAliPjsD7ILDw/UXO33hhqsZNmydIdjWwILxyC0AMAoBAABAIAAIBQCAACASgN5AHyWduh7XJomNBABAIAAIBQCAQNLhizQEEAoBAACuCQACRIBBAJAgEAIEAzBlMNYGF9zSxIAAeLQiRGwAWBACBACAQAAQC0JEg3Tu8xQZYEAAEAoCLBbBIWNeixoIAVLQgrO4OgAUB6EEM0uGXdkaShubfRxHK38z8+6jD92jfsn9stvYCiJZTCMuBRLBZcsixpGmHHvpY0vOZv51I2m37YWfKP5S0lvnbbVP+YccEMpS0YdnfVWFXU2B2MzHI7OZjpMC2bXbkdqwboRbVcyeAOKY9uE9ZK2d7rnuh26/rZmub2eOIQR5nT9KqZf9+y+Xvl5Q/5hERpMfkXMn+1Qa9+NDhmI2S/WvGygECicJqC4IbS5qYGMKXGwiBIJP+ODdngvM8JiWNd9MIY6tG+ScOIj3iMWFBYnFYsv+GRSCbkt6XdKWmOFxinAMeEQKJHaQfWHr3nQBB+k2LddvlESGQ2OxI+omxFlKag7hs3KdJy2VPlQ71XswI5ab5/6a6kysiBllwxoo7pLqnADkE6LdAhqY3tQXLpz36yATGmznHHJnYYuq5zNljRyXnXs+p31TpLII65buwnrkvw5xg/zBTvu+yVaOeI312lO7YbK7P0C8dzqRvqjxLOzIPuuz8U8ce2aVM12NdtqMG5Zc1uMMKdRjVLLtpfV2fX/YZDm3tl0z6I86Zm7vhcOyqpDfM8cM59wp2lY6muY6kbUh6J8AARF6s947j88s+w4mDtbYyqDBDts8CeV7VE3sbmu/pGmNJl2r+djuwOK7U/O1qxupVFcbp7PEnFkEgddmK0FuGCuy3e1DPdTWf03YqkvUq4sjwVQRS3pjmiU3jfvTFBfQxpWfV9TnmeFRfyO7O2RZeIGsqn5jYN9eqT2JuyonS3NBODXFI0oMmFsSqqA5ymsj7odIE30HAB9UFdvT4y1U2bpiGdVGPEqExYkcbr5s29yVTz1kuGtdqzzHeyOO/rpXte6Lwmmkg05nedN/4qDZTPmpY9rGk78yczxYgH+T09FNPAinjwLg2s+UNzb3qUuwyztybPaWjVlfMNZz+v6rFmOXjRRDISY44so13t8FIiQtTVZtZO5H/mbhDlQ+THlhENM3s64pIjo1oD809G5v7NqnpTjWyIH2OQQ5LeuAyv3yk/lN2DbcdLcyOOTYENx3iw0tKczmnAvH9rBZCIBOHY05KRkH6TlkctV/hXPuB6lxlQGHNWLa3TGc4VsHQbsXVcR4sgkBczfUic9zBezV2sCJFHdq2qedOA3FUgunuEJppQ5du1cSWeyEqi0AglmUbqdkbkm8owFA9AplvqgS3m4HrdmpJnjFCOalxjl0P9bDOXkcg/ebIYwPaiXQNE1P2UGle6XKFGGWr7cotVVUU1GYYIQhfk9uo0Vju2Xjf92ScuY4jI+qRsSyXy07gsKwtLlZP2GnBjZmqfMrItmmEw4IGeqg4ScI9Yz22lU4/2c2xLLuKNyVGEu+kh+zNVyVdN/++bRrnsQfRjFWeTd82242MW7Yp95eVfHJOac5l1mJdMnUa61ECOFYdEUhLQafLwm/y7M6MTW/scs6NiA1u3UHMW1XjiiRJjsiDzE/Q3Kb71nUm8r9s6rUYQTrUZz+iMC/24P6c69v9RiD+G+q1SGXvqftLkx4rfWfHB5dDWGwE0o67cy1i2a/X/G0ocY2Vvtx20lAcuyEqi0DaCdbPKU16xRDKvtIcgmvZNyS9oLCv7R6aeKRqBv2Gua+7oSo6mP0I4mAw8P4ZaNuHFjv8Ec95YF3uKyvGYmjqN1L+kPdEj1ZWnOS1rYZtKMk556AzAgFo3Mu3KBBcLABiEAAEAoBAABAIAAIBQCAAvSbIdHeSgdBhBlgQAI8WhO4eAAsCgEAAEAgAAgFAIAAIBACBAMwDLBwHi471DVosCEBFC+L9nXQAYhAABAKAQAAAgQAgEIBGuOZBZke2BjV/1xTKpVxf5Q58CgRg3nASGS4WAAIBQCAA3hnwaQJYyIaf/5mPNDixfR8EAHCxABAIQFP+PwBeCMSPkbrS4wAAAABJRU5ErkJggg==';
			try {
				$('#dragabbleImageInitial').show();
				$('#dragabbleImageInitial').css(
					'z-index',
					'9999999999999999999999999999999999999999999',
				);
				if (recipientcolor == 'rgb(189, 189, 189)') {
					if (
						global.initialimage == '' ||
						global.initialimage == null
					) {
						global.pdf.enableImage(
							dataUrl,
							recipientemail,
							recipientcolor,
							0.3,
							2,
						);
					} else {
						global.pdf.enableImage(
							global.initialimage,
							recipientemail,
							'transparent',
							0.6,
							2,
						);
					}
				} else {
					global.pdf.enableImage(
						dataUrl,
						recipientemail,
						recipientcolor,
						0.3,
						2,
					);
				}
			} catch (error) {
				alert('Add a Document');
				$('#dragabbleImageInitial').hide();
			}
		}

		$(document).on("click", "#initialbtn", global.initialbtnClickHandler)

		$('#requiredcheck').change(function () {
			if (this.checked) {
				var select = document.getElementById('recipientselect');
				var bgcolor =
					select.options[select.selectedIndex].style.backgroundColor;
				formattingobject.set('backgroundColor', bgcolor);
			} else {
				formattingobject.set('backgroundColor', 'transparent');
				global.pdf.Reload();
			}
		});

		$('#input-pixels-left').change(function () {
			var left = document.getElementById('input-pixels-left').value;
			formattingobject.set({ left: parseInt(left) });
			global.pdf.Reload();
		});

		$('#input-pixels-top').change(function () {
			var top = document.getElementById('input-pixels-top').value;
			formattingobject.set({ top: parseInt(top) });
			global.pdf.Reload();
		});

		$('#input-scale-value').change(function () {
			var scale = document.getElementById('input-scale-value').value;
			var scaleX = formattingobject.scaleX;
			var scaleY = formattingobject.scaleY;
			scaleX = parseFloat(scale) * 0.003;
			scaleY = parseFloat(scale) * 0.003;
			formattingobject.set({
				scaleX: parseFloat(scaleX),
				scaleY: parseFloat(scaleY),
			});
			global.pdf.Reload();
		});

		global.boldbtnClickHandler = function (event) {
			dtEditText('bold');
		};
		global.italicbtnClickHandler = function (event) {
			dtEditText('italic');
		};
		global.underlinebtnClickHandler = function (event) {
			dtEditText('underline');
		};

		$(document).on("click", "#boldbtn", global.boldbtnClickHandler);
		$(document).on("click", "#italicbtn", global.italicbtnClickHandler);
		$(document).on("click", "#underlinebtn", global.underlinebtnClickHandler);

		// Functions
		function dtEditText(action) {
			var a = action;
			var o = formattingobject;
			var t;

			// If object selected, what type?
			if (o) {
				t = o.get('type');
			}

			if (o && t === 'i-text') {
				switch (a) {
					case 'bold':
						var isBold = dtGetStyle(o, 'fontWeight') === 'bold';
						dtSetStyle(o, 'fontWeight', isBold ? '' : 'bold');
						break;

					case 'italic':
						var isItalic = dtGetStyle(o, 'fontStyle') === 'italic';
						dtSetStyle(o, 'fontStyle', isItalic ? '' : 'italic');
						break;

					case 'underline':
						var isUnderline = o.underline;
						dtUnderlineStyle(
							o,
							'underline',
							isUnderline ? false : true,
						);
						break;
						global.pdf.Reload();
				}
			}
		}

		// Get the style
		function dtGetStyle(object, styleName) {
			return object[styleName];
		}

		// Set the style
		function dtSetStyle(object, styleName, value) {
			object[styleName] = value;
			object.set({ dirty: true });
			global.pdf.Reload();
		}

		function dtUnderlineStyle(object, styleName, value) {
			object.underline = value;
			object.set({ dirty: true });
			global.pdf.Reload();
		}

		var fonts = [
			'Arial',
			'Times New Roman',
			'Courier',
			'Verdana',
			'Palatino',
		];

		var fontselect = document.getElementById('fontselect');
		fonts.forEach(function (font) {
			var option = document.createElement('option');
			option.innerHTML = font;
			option.value = font;
			fontselect.appendChild(option);
		});

		// Apply selected font on change
		document.getElementById('fontselect').onchange = function () {
			formattingobject.set('fontFamily', this.value);
			global.pdf.Reload();
		};

		var colorArray = [
			'#E6EE9C',
			'#B6EDD8',
			'#FFCDD3',
			'#90CAF9',
			'#E1BEE7',
			'#A5D6A7',
			'#B3E2E3',
			'#BCAAA4',
			'#E0E0E0',
			'#FFAB00',
			'#64DD17',
			'#00B8D4',
			'#00BFA5',
		];

		global.startsigndocbtnClickHandler = (event) => {
			if (document.getElementById('signtermscheck').checked) {
				$("#agreementModal").hide();
			} else {
				alert('Please agree to our terms and conditions to continue');
			}
		}

		$(document).on("click", "#startsigndocbtn", global.startsigndocbtnClickHandler)

		global.backbtnClickHandler = function (event) {
			window.history.go(-1);
		}

		$(document).on('click', '#backbtn', global.backbtnClickHandler)

		global.onlysignerfinishbtnClickHandler = function (event) {
			try {
				$("#saveLoadingModal").show();
                global.pdf.OnlySignerSave();
			} catch (error) {
				alert('There are no changes to save');
			}
		}

		$(document).on("click", "#onlysignerfinishbtn", global.onlysignerfinishbtnClickHandler)

		global.recieverfinishbtnClickHandler = function (event) {
			$("#saveLoadingModal").show();
			global.pdf.checkallupdated();
		}

		$(document).on("click", "#recieverfinishbtn", global.recieverfinishbtnClickHandler)

		global.recieverfinishlaterbtnClickHandler = function (event) {
			window.location.hash = '#/admin/manage';
		}
		$(document).on("click", "#recieverfinishlaterbtn", global.recieverfinishlaterbtnClickHandler)

		global.recieverdeclinebtnClickHandler = async function (event) {
			var today = new Date().toLocaleString().replace(',', '');
			axios
				.post('/api/updatedocumentstatus', {
					DocumentID: filename,
					Status: 'Void',
					Owner: useridother,
				})
				.then(async function (response) {
					if (response.data === 'insert done' || response.data === 'update done') {
						$("#sendEmailLoadingModal").show();

						try {
							await axios
								.post('/api/posthistory', {
									DocumentID: filename,
									HistoryTime: today,
									HistoryUser: email + '\n[' + ip + ']',
									HistoryAction: 'Declined',
									HistoryActivity:
										'' +
										email +
										' declined signing the envelope',
									HistoryStatus: 'Declined',
									Owner: useridother,
								});

                            var recievers = global.doc.Document.Reciever;
                            var managevoidmessage =
                                'One or more recepients have declined the document';
                            var DocumentName = '';

                            recievers.forEach(async function (item, index) {
                                DocumentName = item.DocumentName;
                                recievers[index].RecipientStatus = 'Void';
                                recievers[index].RecipientDateStatus = today;

                                await axios
                                    .post('/api/updaterecieverdata', {
                                        Reciever: recievers,
                                        Owner: filename,
                                    });

                                await axios
                                    .post('/api/getRequests', {
                                        UserID: useridother,
                                    })
                                    .then(function (response) {
                                        if (response.data.Status === 'got request') {
                                            var request = response.data.Request;

                                            request.forEach(function (item, index,) {
                                                if (request[index].DocumentID === filename) {
                                                    request[index].RecipientStatus = 'Void';
                                                    request[index].RecipientDateStatus = today;
                                                    axios.post('/api/updaterequestdata', {
                                                        UserID: userid,
                                                        Request: request,
                                                    })
                                                }
                                            });
                                        }
                                    })

                                var loginUserName = getCookie('UserFullName');

                                await axios
                                    .post('/api/sendmail', {
                                        to: item.RecipientEmail,
                                        body: VoidedEmail({
                                            DocumentName: DocumentName,
                                            ValidReason: managevoidmessage,
                                            UserName: loginUserName,
                                        }),
                                        subject: `${APP_CONFIG.APP_NAME}: Voided ${DocumentName}`,
                                    });
                            });
						} catch (e) {
							console.log(e)
						}

						window.location.hash = '#/admin/index';
						$("#sendEmailLoadingModal").hide();
					}
				});
		}

		$(document).on("click", "#recieverdeclinebtn", global.recieverdeclinebtnClickHandler)

		global.sendEmailBtnClickHandler = async function (e) {
			$(this).text('Loading...').attr('disabled', true);
			const counterObj = {};
			for (const rec of DataVar.RecipientArray) {
				if (rec.option === 'Needs to Sign') {
					counterObj[rec.email] = 0;
				}
			}

			for (const fabricObj of global.pdf.fabricObjects) {
				for (const targ of fabricObj.getObjects()) {
					if (counterObj.hasOwnProperty(targ.id)) {
						counterObj[targ.id] += 1;
					}
				}
			}

			const recipientsWithZeroObject = Object.keys(counterObj).filter(x => counterObj[x] === 0);

			try {
				if (recipientsWithZeroObject.length !== 0) {
					$('#noObjectsConfirmation').show();
				} else {
					await global.pdf.savetoCloudPdf();
					if (action === 'correct') {
						window.location.hash =
							'#/admin/review?id=' + filename + '&action=correct';
					} else {
						window.location.hash = '#/admin/review?id=' + filename + '';
					}
				}
			} catch (e) {
				console.error(e)
			}
			$(this).text('Next').attr('disabled', false);
		};

		$(document).on('click', '#sendemailbtn', global.sendEmailBtnClickHandler);

		global.addfieldsbtnClickHandler = function (event) {
			$('#noObjectsConfirmation').css('display', 'none');
		}

		$(document).on('click', '#addfieldsbtn', global.addfieldsbtnClickHandler)

		global.sendwithoutfieldsbtnClickHandler = function (event) {
			$('#noObjectsConfirmation').css('display', 'none');
			window.location.hash = '#/admin/review?id=' + filename + '';
		}

		$(document).on('click', '#sendwithoutfieldsbtn', global.sendwithoutfieldsbtnClickHandler)

		$(document).on('click', '.manage-pdf-download-btn', function () {
			var index = $('.manage-pdf-download-btn').index(this);
			$("#saveLoadingModal").show();
            global.pdf.DownloadIndividual(index);
		});

		$(document).on('click', '.thumb-pdf-canvas', function () {
			var index = $(this).index();
            var pageHeight = $('#pdf-container .canvas-container').height();
            $('#container').animate({ scrollTop: index * (pageHeight + 25) }, 1000,);
		});

		var droptogglesign = 0;

		$(document).on('click', '.actionsign', function () {
			$('.dropdown-menu2').css({ display: 'none' });
			if (droptogglesign === 0) {
				$(this).parent().children('#dropdown')[0].style.display =
					'block';
				droptogglesign = 1;
			} else if (droptogglesign === 1) {
				droptogglesign = 0;
				$(this).parent().children('#dropdown')[0].style.display =
					'none';
			}
		});

		if (action == 'correct') {
			$('#ppsActionBtns').hide();
		}

        try {
            userid = isSignMode() ? null : getCookie('uid');

            try {
                var mainurl = document.location.hash,
                    params = mainurl.split('?')[1].split('&'),
                    data = {},
                    tmp;
                for (var i = 0, l = params.length; i < l; i++) {
                    tmp = params[i].split('=');
                    data[tmp[0]] = tmp[1];
                }
                filename = data.id;
                fileid = data.id;
                type = data.type;
                useridother = data.u;
                key = data.key;
            } catch (error) { }

            if (isSignMode()) {
                $("#prepareLoadingModal").show();
                $("#agreementModal").show();

                // Set class for sign page and alter page
                document.body.classList.add('sign-screen');
                document.getElementById('pdfcol').classList.remove('col-lg-8');
                document.getElementById('pdfcol').classList.add('col-lg-10');
                document.getElementById('fieldsleftbar').style.display = 'none';

                document.getElementById(
                    'fieldsleftbar',
                ).style.display = 'none';
                document.getElementById('textbtn').style.display =
                    'none';
                document.getElementById(
                    'signaturebtn',
                ).style.display = 'none';
                document.getElementById('deletebtn').style.display =
                    'none';
                document.getElementById('clearbtn').style.display =
                    'none';
                document.getElementById('datebtn').style.display =
                    'none';
                document.getElementById('namebtn').style.display =
                    'none';
                document.getElementById('titlebtn').style.display =
                    'none';
                document.getElementById(
                    'companybtn',
                ).style.display = 'none';
                document.getElementById(
                    'initialbtn',
                ).style.display = 'none';
                document.getElementById(
                    'recipientselect',
                ).style.display = 'none';
                document.getElementById(
                    'fieldscolumn',
                ).style.display = 'none';

                const response = await axios
                    .post('/api/getdocdata', {
                        DocumentID: fileid,
                        Owner: useridother
                    });

                if (response.data.Status === 'doc data done') {
                    DataVar.Backgrounds = [];
                    global.doc = response.data;
                    signorderval = response.data.SignOrder;
                    DataVar.Objects = response.data.Data.map((x, i) => {
                        const obj = JSON.parse(x);
                        DataVar.Backgrounds[i] = obj.backgroundImage;
                        delete obj.backgroundImage;
                        return obj;
                    });

                    $("#movecursorbtn").show();
                } else {
                    return alert('doc not found')
                }
            }

            if (userid) {
                email = getCookie('useremail');
                var cookierecents = getCookie('recents');
                if (cookierecents) {
                    recents = JSON.parse(cookierecents);
                }

                // Get detault recipients from datavar
                // TODO: This is not useful so check and remove
                var people = [];
                let optiondefault = document.createElement('option');
                optiondefault.value = email;
                optiondefault.style.backgroundColor = '#bdbdbd';
                people = DataVar.RecipientArray;
                if (people.length === 0) {
                    optiondefault.innerHTML = 'Default(Me)';
                    $('#recipientselect').append(optiondefault);
                }

                // Get current user data
                // TODO: getuserdata API endpoint is hit multiple times from the same page, optimise it
                axios
                    .post('/api/getuserdata', {
                        UserID: userid,
                    })
                    .then(function (response) {
                        if (response.data.Status === 'user found') {
                            const { user } = response.data;
                            if (user.SignID != '') {
                                if (user.SignImage) {
                                    if (APP_CONFIG.ENABLE_SIGN_BOX) {
                                        global.signimage = user.SignImageBox;
                                        global.initialimage = user.InitialsBox;
                                    } else {
                                        global.signimage = user.SignImage;
                                        global.initialimage = user.Initials;
                                    }

                                    username =
                                        user.UserFirstName +
                                        ' ' +
                                        user.UserLastName;
                                    usertitle = user.UserTitle;
                                }
                            }
                        }
                    })
                    .catch(function (error) {
                        console.log(error);
                    });

                // Gets the data from URL
                // Checks what screen to display based on url data
                try {
                    var mainurl = document.location.hash,
                        params = mainurl.split('?')[1].split('&'),
                        data = {},
                        tmp;
                    for (var i = 0, l = params.length; i < l; i++) {
                        tmp = params[i].split('=');
                        data[tmp[0]] = tmp[1];
                    }
                    filename = data.id;
                    type = data.type;
                    useridother = data.u;
                    fileid = data.id;
                    action = data.action;
                } catch (error) { }

                if (filename == '' || useridother == '') {
                    // If the URL does not have the document ID then it usually means
                    // self signing user so show/hide elements accordingly.

                    $("#prepareLoadingModal").hide();
                    owner = 'admin';

                    if (DataVar.OnlySigner == true) {
                        $("#onlysignerfinishbtn").show();
                    }

                    // Load recipients to dropdown
                    var people = [];
                    people = DataVar.RecipientArray;
                    people.forEach(function (item, index) {
                        if (people[index].option == 'Needs to Sign') {
                            var option = document.createElement('option');
                            option.value = people[index].email;
                            option.style.backgroundColor = colorArray[index];
                            option.innerHTML = '' + people[index].name + '';
                            $('#recipientselect').append(option);
                        }
                    });

                    document.getElementById('recieverfinishbtn').style.display =
                        'none';
                    document.getElementById('moreoptions').style.display =
                        'none';
                } else {
                    if (userid != useridother) {
                        try {
                            document.getElementById(
                                'fieldsleftbar',
                            ).style.display = 'none';
                            document.getElementById(
                                'fieldsrightbar',
                            ).style.display = 'none';
                            document.getElementById('textbtn').style.display =
                                'none';
                            document.getElementById(
                                'signaturebtn',
                            ).style.display = 'none';
                            document.getElementById('deletebtn').style.display =
                                'none';
                            document.getElementById('clearbtn').style.display =
                                'none';
                            document.getElementById('datebtn').style.display =
                                'none';
                            document.getElementById('namebtn').style.display =
                                'none';
                            document.getElementById('titlebtn').style.display =
                                'none';
                            document.getElementById(
                                'companybtn',
                            ).style.display = 'none';
                            document.getElementById(
                                'initialbtn',
                            ).style.display = 'none';
                            document.getElementById(
                                'recipientselect',
                            ).style.display = 'none';
                            document.getElementById(
                                'fieldscolumn',
                            ).style.display = 'none';
                            document.getElementById(
                                'recipientscolumn',
                            ).style.display = 'none';
                        } catch (error) { }

                        var remail = '';
                        var today = new Date()
                            .toLocaleString()
                            .replace(',', '');

                        const response = await axios
                            .post('/api/getReciever', {
                                DocumentID: filename,
                                Owner: useridother,
                            })

                        var recievers = response.data.Reciever;
                        var status = response.data.DocStatus;
                        var OwnerEmail = response.data.OwnerEmail;
                        var DocumentName = response.data.DocumentName;

                        if (
                            status === 'Void' ||
                            status === 'Deleted' ||
                            status === 'Correcting'
                        ) {
                            $("#prepareLoadingModal").hide();
                            window.location.hash = '#/admin/index';
                        }

                        recievers.forEach(function (item, index) {
                            dbpeople.push({
                                name:
                                recievers[index].RecipientName,
                                email:
                                recievers[index].RecipientEmail,
                                option:
                                recievers[index]
                                    .RecipientOption,
                            });

                            if (item.RecipientEmail === email) {
                                grabbedcolor = item.RecipientColor;
                                remail = item.RecipientEmail;

                                var rgbval =
                                    hexToRgb(grabbedcolor).r +
                                    ', ' +
                                    hexToRgb(grabbedcolor).g +
                                    ', ' +
                                    hexToRgb(grabbedcolor).b;

                                recipientrgbval =
                                    'rgb(' + rgbval + ')';

                                axios
                                    .post('/api/posthistory', {
                                        DocumentID: filename,
                                        HistoryTime: today,
                                        HistoryUser:
                                            email +
                                            '\n[' +
                                            ip +
                                            ']',
                                        HistoryAction:
                                            'Viewed In-Session',
                                        HistoryActivity:
                                            '' +
                                            email +
                                            ' viewed the envelope in a session hosted by ' +
                                            OwnerEmail +
                                            ' [documents:(' +
                                            DocumentName +
                                            ')]',
                                        HistoryStatus: 'Completed',
                                        Owner: useridother,
                                    })
                                    .then(function (response) {
                                        console.log(response);
                                    })
                                    .catch(function (error) {
                                        console.log(error);
                                    });
                            }
                        });

                        if (action === 'correct') {
                            try {
                                owner = 'admin';
                                action = 'create';
                                var people = [];
                                people = DataVar.RecipientArray;
                                people.forEach(function (item, index) {
                                    if (
                                        people[index].option == 'Needs to Sign'
                                    ) {
                                        var option = document.createElement(
                                            'option',
                                        );
                                        option.value = people[index].email;
                                        option.style.backgroundColor =
                                            colorArray[index];
                                        option.innerHTML =
                                            '' + people[index].name + '';
                                        $('#recipientselect').append(option);
                                    }
                                });
                            } catch (error) { }
                        } else if (action === 'create') {
                            try {
                                owner = 'admin';
                                action = 'create';
                                document.getElementById(
                                    'recieverfinishbtn',
                                ).style.display = 'none';
                                document.getElementById(
                                    'recieverfinishlaterbtn',
                                ).style.display = 'none';
                                document.getElementById(
                                    'recieverdeclinebtn',
                                ).style.display = 'none';
                                document.getElementById(
                                    'textbtn',
                                ).style.display = 'block';
                                document.getElementById(
                                    'signaturebtn',
                                ).style.display = 'block';
                                document.getElementById(
                                    'deletebtn',
                                ).style.display = 'block';
                                document.getElementById(
                                    'clearbtn',
                                ).style.display = 'block';
                                document.getElementById(
                                    'datebtn',
                                ).style.display = 'block';
                                document.getElementById(
                                    'namebtn',
                                ).style.display = 'block';
                                document.getElementById(
                                    'titlebtn',
                                ).style.display = 'block';
                                document.getElementById(
                                    'companybtn',
                                ).style.display = 'block';
                                document.getElementById(
                                    'initialbtn',
                                ).style.display = 'block';
                                document.getElementById(
                                    'recipientselect',
                                ).style.display = 'block';
                                document.getElementById(
                                    'fieldscolumn',
                                ).style.display = 'block';
                                document.getElementById(
                                    'recipientscolumn',
                                ).style.display = 'block';

                                var people = [];
                                people = DataVar.RecipientArray;
                                people.forEach(function (item, index) {
                                    if (
                                        people[index].option == 'Needs to Sign'
                                    ) {
                                        var option = document.createElement(
                                            'option',
                                        );
                                        option.value = people[index].email;
                                        option.style.backgroundColor =
                                            colorArray[index];
                                        option.innerHTML =
                                            '' + people[index].name + '';
                                        $('#recipientselect').append(option);
                                    }
                                });
                            } catch (error) { }
                        }
                    } else {
                        document.getElementById(
                            'recieverfinishbtn',
                        ).style.display = 'none';
                        document.getElementById('moreoptions').style.display =
                            'none';
                        owner = 'notadmin';

                        const response = await axios
                            .post('/api/getReciever', {
                                DocumentID: filename,
                                Owner: useridother,
                            })

                        var recievers = response.data.Reciever;
                        var status = response.data.DocStatus;
                        var OwnerEmail = response.data.OwnerEmail;
                        var DocumentName = response.data.DocumentName;

                        if (status === 'Void') {
                            $("#prepareLoadingModal").hide();
                            window.location.hash = '#/admin/index';
                        }

                        recievers.forEach(function (item, index) {
                            dbpeople.push({
                                name:
                                recievers[index].RecipientName,
                                email:
                                recievers[index].RecipientEmail,
                                option:
                                recievers[index]
                                    .RecipientOption,
                            });

                            if (item.RecipientEmail === email) {
                                document.getElementById(
                                    'recieverfinishbtn',
                                ).style.display = 'block';
                                document.getElementById(
                                    'moreoptions',
                                ).style.display = 'block';

                                try {
                                    document.getElementById(
                                        'fieldsleftbar',
                                    ).style.display = 'none';
                                    document.getElementById(
                                        'fieldsrightbar',
                                    ).style.display = 'none';
                                    document.getElementById(
                                        'textbtn',
                                    ).style.display = 'none';
                                    document.getElementById(
                                        'signaturebtn',
                                    ).style.display = 'none';
                                    document.getElementById(
                                        'deletebtn',
                                    ).style.display = 'none';
                                    document.getElementById(
                                        'clearbtn',
                                    ).style.display = 'none';
                                    document.getElementById(
                                        'datebtn',
                                    ).style.display = 'none';
                                    document.getElementById(
                                        'namebtn',
                                    ).style.display = 'none';
                                    document.getElementById(
                                        'titlebtn',
                                    ).style.display = 'none';
                                    document.getElementById(
                                        'companybtn',
                                    ).style.display = 'none';
                                    document.getElementById(
                                        'initialbtn',
                                    ).style.display = 'none';
                                    document.getElementById(
                                        'recipientselect',
                                    ).style.display = 'none';
                                    document.getElementById(
                                        'fieldscolumn',
                                    ).style.display = 'none';
                                    document.getElementById(
                                        'recipientscolumn',
                                    ).style.display = 'none';
                                } catch (error) { }

                                grabbedcolor = item.RecipientColor;
                                remail = item.RecipientEmail;

                                var rgbval =
                                    hexToRgb(grabbedcolor).r +
                                    ', ' +
                                    hexToRgb(grabbedcolor).g +
                                    ', ' +
                                    hexToRgb(grabbedcolor).b;

                                recipientrgbval =
                                    'rgb(' + rgbval + ')';

                                axios
                                    .post('/api/posthistory', {
                                        DocumentID: filename,
                                        HistoryTime: today,
                                        HistoryUser:
                                            email +
                                            '\n[' +
                                            ip +
                                            ']',
                                        HistoryAction:
                                            'Viewed In-Session',
                                        HistoryActivity:
                                            '' +
                                            email +
                                            ' viewed the envelope in a session hosted by ' +
                                            OwnerEmail +
                                            ' [documents:(' +
                                            DocumentName +
                                            ')]',
                                        HistoryStatus: 'Completed',
                                        Owner: useridother,
                                    })
                                    .then(function (response) {
                                        console.log(response);
                                    })
                                    .catch(function (error) {
                                        console.log(error);
                                    });
                            }
                        });

                        if (action === 'correct') {
                            try {
                                owner = 'admin';
                                action = 'correct';
                                var people = [];
                                people = DataVar.RecipientArray;
                                userid = useridother;
                                people.forEach(function (item, index) {
                                    if (
                                        people[index].option == 'Needs to Sign'
                                    ) {
                                        var option = document.createElement(
                                            'option',
                                        );
                                        option.value = people[index].email;
                                        option.style.backgroundColor =
                                            colorArray[index];
                                        option.innerHTML =
                                            '' + people[index].name + '';
                                        $('#recipientselect').append(option);
                                    }
                                });
                            } catch (error) { }
                        } else if (action === 'create') {
                            try {
                                owner = 'admin';
                                action = 'create';
                                var people = [];
                                people = DataVar.RecipientArray;
                                userid = useridother;
                                people.forEach(function (item, index) {
                                    if (
                                        people[index].option == 'Needs to Sign'
                                    ) {
                                        var option = document.createElement(
                                            'option',
                                        );
                                        option.value = people[index].email;
                                        option.style.backgroundColor =
                                            colorArray[index];
                                        option.innerHTML =
                                            '' + people[index].name + '';
                                        $('#recipientselect').append(option);
                                    }
                                });
                            } catch (error) { }
                        }
                    }

                    alert('docdownload')
                }
            } else {
                userid = 'none';

                var optiondefault = document.createElement('option');
                optiondefault.value = email;
                optiondefault.style.backgroundColor = '#bdbdbd';
                optiondefault.innerHTML = 'Default(Me)';
                $('#recipientselect').append(optiondefault);

                // prepare document
                if (filename == '' || useridother == '') {
                    owner = 'admin';
                    try {
                        var people = [];
                        people = DataVar.RecipientArray;
                        people.forEach(function (item, index) {
                            if (people[index].option == 'Needs to Sign') {
                                var option = document.createElement('option');
                                option.value = people[index].email;
                                option.style.backgroundColor =
                                    colorArray[index];
                                option.innerHTML = '' + people[index].name + '';
                                $('#recipientselect').append(option);
                            }
                        });
                    } catch (error) { }

                    document.getElementById('recieverfinishbtn').style.display =
                        'none';
                    document.getElementById('moreoptions').style.display =
                        'none';
                } else {
                    //sign document
                    var today = new Date()
                        .toLocaleString()
                        .replace(',', '');

                    const response = await axios
                        .post('/api/getReciever', {
                            DocumentID: filename,
                            Owner: useridother,
                        })

                    var recievers = response.data.Reciever;
                    var status = response.data.DocStatus;
                    var OwnerEmail = response.data.OwnerEmail;
                    var DocumentName = response.data.DocumentName;

                    const currentUser = recievers.find((a, index) => index == key);
                    if (currentUser && currentUser.RecipientStatus == "Completed") {
                        $('#prepareLoadingModal').hide();
                        $('#agreementModal').hide();
                        $('#operationModal').show();
                        return false;
                    }

                    if (status === 'Void' || status === 'Deleted' || status === 'Correcting'
                    ) {
                        $('#prepareLoadingModal').hide();
                        return window.location.hash =
                            '#/admin/index';
                    }
                    recievers.forEach(function (item, index,) {
                        dbpeople.push({
                            name: recievers[index].RecipientName,
                            email: recievers[index].RecipientEmail,
                            option: recievers[index].RecipientOption,
                        });
                    });
                    grabbedcolor = recievers[key].RecipientColor;
                    remail = recievers[key].RecipientEmail;
                    email = recievers[key].RecipientEmail;

                    this.setState({
                        defaultName:
                        recievers[key]
                            .RecipientName,
                        defaultInitial: generateInitial(
                            recievers[key]
                                .RecipientName,
                        ),
                    });

                    axios
                        .post('/api/posthistory', {
                            DocumentID: filename,
                            HistoryTime: today,
                            HistoryUser:
                                email +
                                '\n[' +
                                ip +
                                ']',
                            HistoryAction:
                                'Viewed In-Session',
                            HistoryActivity:
                                '' +
                                email +
                                ' viewed the envelope in a session hosted by ' +
                                OwnerEmail +
                                ' [documents:(' +
                                DocumentName +
                                ')]',
                            HistoryStatus: 'Completed',
                            Owner: useridother,
                        })

                    var rgbval =
                        hexToRgb(grabbedcolor).r +
                        ', ' +
                        hexToRgb(grabbedcolor).g +
                        ', ' +
                        hexToRgb(grabbedcolor).b;
                    recipientrgbval =
                        'rgb(' + rgbval + ')';
                }
            }

            global.pdf = new PDFAnnotate(
                'pdf-container',
                DataVar.DocName,
            );
        } catch (err) {
            $("#prepareLoadingModal").hide();
        }
	}

	proceedShortcut = async (type) => {
		if (this.pdf === null) return;

		const active_canvas = this.pdf.fabricObjects[this.pdf.active_canvas];
		const recipientList = $('#recipientselect option');
		const selectedRecipientIndex = $('#recipientselect').prop(
			'selectedIndex',
		);

		if (type === SHORTCUT_DEFINITION.COPY) {
			await new Promise((resolve) => {
				const obj = active_canvas.getActiveObject();
				if (!obj) return resolve();

				obj.clone((cloned) => {
					this.clipboard = cloned;

					resolve();
				}, FABRICJS_PROPERTIES_TO_INCLUDED);
			});
		} else if (type === SHORTCUT_DEFINITION.PASTE) {
			if (this.clipboard) {
				this.clipboard.clone((clonedObj) => {
					active_canvas.discardActiveObject();
					const config = {
						left: clonedObj.left + 20,
						top: clonedObj.top + 20,
						evented: true,
					};
					clonedObj.set(config);
					this.clipboard.set(config);
					active_canvas.add(clonedObj);
					active_canvas.setActiveObject(clonedObj);
					active_canvas.requestRenderAll();
				}, FABRICJS_PROPERTIES_TO_INCLUDED);
			}
		} else if (type === SHORTCUT_DEFINITION.CUT) {
			const obj = active_canvas.getActiveObject();
			if (!obj) return;
			obj.clone((cloned) => {
				this.clipboard = cloned;
			}, FABRICJS_PROPERTIES_TO_INCLUDED);
			active_canvas.remove(obj);
		} else if (type === SHORTCUT_DEFINITION.DELETE) {
			$('#deletebtn').click();
		} else if (type === SHORTCUT_DEFINITION.DUPLICATE) {
			await this.proceedShortcut(SHORTCUT_DEFINITION.COPY);
			this.proceedShortcut(SHORTCUT_DEFINITION.PASTE);
		} else if (type === SHORTCUT_DEFINITION.CANCEL) {
			$('.tool.active').removeClass('active');
			$('.icon-color').removeClass('icon-color');

			$('#dragabbleImageText').hide();
			$('#dragabbleImageSign').hide();
			$('#dragabbleImageInitial').hide();

			this.pdf.active_tool = 0;
		} else if (type === SHORTCUT_DEFINITION.SAVE) {
			if (DataVar.OnlySigner) {
				$('#onlysignerfinishbtn').click();
			} else {
				$('#sendemailbtn').click();
			}
		} else if (type === SHORTCUT_DEFINITION.CHANGE_RECIPIENT_UP) {
			if (recipientList.length === 1) return;
			this.proceedShortcut(SHORTCUT_DEFINITION.CANCEL);

			let newIndex = selectedRecipientIndex - 1;

			if (newIndex < 0) {
				newIndex = recipientList.length - 1;
			}

			$('#recipientselect')
				.prop('selectedIndex', newIndex)
				.trigger('change');
		} else if (type === SHORTCUT_DEFINITION.CHANGE_RECIPIENT_DOWN) {
			if (recipientList.length === 1) return;
			this.proceedShortcut(SHORTCUT_DEFINITION.CANCEL);

			let newIndex = selectedRecipientIndex + 1;

			if (newIndex === recipientList.length) {
				newIndex = 0;
			}

			$('#recipientselect')
				.prop('selectedIndex', newIndex)
				.trigger('change');
		} else if (type === SHORTCUT_DEFINITION.MOVE_UP) {
			const selector = document.getElementById('input-pixels-top');
			selector.value = parseInt(selector.value) - 1;
			selector.dispatchEvent(new Event('change'));
		} else if (type === SHORTCUT_DEFINITION.MOVE_DOWN) {
			const selector = document.getElementById('input-pixels-top');
			selector.value = parseInt(selector.value) + 1;
			selector.dispatchEvent(new Event('change'));
		} else if (type === SHORTCUT_DEFINITION.MOVE_LEFT) {
			const selector = document.getElementById('input-pixels-left');
			selector.value = parseInt(selector.value) - 1;
			selector.dispatchEvent(new Event('change'));
		} else if (type === SHORTCUT_DEFINITION.MOVE_RIGHT) {
			const selector = document.getElementById('input-pixels-left');
			selector.value = parseInt(selector.value) + 1;
			selector.dispatchEvent(new Event('change'));
		}
	};

	toggleShortcutModal = () => {
		window.dispatchEvent(
			new KeyboardEvent("keydown", {
				code: "KeyS",
				ctrlKey: true,
				altKey: true
			})
		);
	}

	togglePreview = () => {
		const hasPreview = $("#fieldsrightbar").css('display') !== "none";
		const containerFullSize = isSignMode() ? 12 : 10;
		const containerSmallSize = isSignMode() ? 10 : 8;
		if (hasPreview) {
			$("#fieldsrightbar").css({
				display: "none"
			})
			$("#pdfcol").attr('class', `col-lg-${containerFullSize}`);
		} else {
			$("#fieldsrightbar").css({
				display: "block"
			})
			$("#pdfcol").attr('class', `col-lg-${containerSmallSize}`);
		}
	}

	render() {
		const {
			showSignModal,
			signType,
			defaultName,
			defaultInitial,
		} = this.state;
		return (
			<div className="pdfAnNotateContainer">
				<img
					id="dragabbleImageSign"
					style={{
						zIndex: '99999999999999999999999999999999999999999',
					}}
					src={require('../../assets/img/icons/common/sign-here.png')}
				/>

				<img
					id="dragabbleImageText"
					style={{
						zIndex: '99999999999999999999999999999999999999999',
					}}
					src={require('../../assets/img/icons/common/textimg.png')}
				/>

				<img
					id="dragabbleImageInitial"
					style={{
						zIndex: '99999999999999999999999999999999999999999',
					}}
					src={require('../../assets/img/icons/common/initialimg.png')}
				/>

				<Row id="ppsActionBtns" className="mb-3">
					<Col lg="12" className="d-flex justify-content-between">
						<div id="moreoptions" className="btn-group">
							<button
								type="button"
								className="btn btn-neutral actionsign ">
								Other Actions
							</button>
							<button
								type="button"
								className="btn btn-neutral actionsign dropdown-toggle dropdown-toggle-split"
							/>
							<div className="dropdown-menu2" id="dropdown">
								<button
									className="dropdown-item "
									id="recieverfinishlaterbtn"
									type="button">
									Finish Later
								</button>
								<button
									className="dropdown-item "
									id="recieverdeclinebtn"
									type="button">
									Decline
								</button>
								<div className="dropdown-divider" />
								<button
									className="dropdown-item"
									onClick={this.openSite}
									type="button">
									Help & Support
								</button>
								<button
									className="dropdown-item"
									onClick={this.openSite}
									type="button">
									About {APP_CONFIG.APP_NAME}
								</button>
							</div>
						</div>
						<button
							type="button"
							id="recieverfinishbtn"
							className="btn m-2 float-right px-4 btn-primary ">
							Finish
						</button>
					</Col>
				</Row>

				<div id="prepareLoadingModal" className="modal">
					<div className="modal-content modal-dialog">
						<div>
							<p>Please wait while we set things up for you.</p>
							<div className="lds-dual-ring" />
						</div>
					</div>
				</div>

				<div id="saveLoadingModal" className="modal">
					<div className="modal-content modal-dialog">
						<div>
							<p>
								Please wait while we save the changes you have
								made.
							</p>
							<div className="lds-dual-ring" />
						</div>
					</div>
				</div>

				<div id="sendEmailLoadingModal" className="modal">
					<div className="modal-content modal-dialog">
						<div>
							<p>
								Sending Email, This dialog will automatically
								close after sending.
							</p>
							<div className="lds-dual-ring" />
						</div>
					</div>
				</div>
				<div id="operationModal" className="modal">
					<div className="review-act-modal-content modal-content modal-dialog">
						<div>
							<Row className="m-3">
								<Col xs="12">
									<div className="mb-4 mb-xl-0 float-left">
										<h3>
											This operation has already performed{' '}
										</h3>
									</div>
								</Col>
							</Row>
							<Button
								onClick={() => window.location.hash = '#/admin/manage'}
								id="operationpeformed"
								className="close-btn px-4 mx-4 ">
								{' '}
								OK
							</Button>
						</div>
					</div>
				</div>
				<div id="agreementModal" className="modal">
					<div className="review-act-modal-content modal-content modal-dialog">
						<div>
							<Row className="m-3">
								<Col xs="12">
									<div className="mb-4 mb-xl-0 float-left">
										<h3>
											Please Review and Act on These
											Documents:{' '}
										</h3>
									</div>
								</Col>
								<Col xs="12" className="py-3">
									<div className="custom-control custom-control-alternative custom-checkbox">
										<input
											className="custom-control-input"
											id="signtermscheck"
											type="checkbox"
										/>
										<label
											className="custom-control-label"
											htmlFor="signtermscheck">
											<span className="text-muted">
												I agree to use electronic
												records, signature and{' '}
												<a
													href="#"
													onClick={(e) =>
														e.preventDefault()
													}>
													Electronic Record and
													Signature Disclosure
												</a>
											</span>
										</label>
									</div>
								</Col>
							</Row>
							<Button
								id="startsigndocbtn"
								className="close-btn float-right px-4 mx-4 ">
								{' '}
								Continue
							</Button>
						</div>
					</div>
				</div>

				<div className="modal" id="noObjectsConfirmation">
					<div className="modal-content modal-dialog">
						<div>
							<Row className="m-3">
								<Col xs="12">
									<div className="mb-4 mb-xl-0 float-left">
										<h3>Add fields for your recipients </h3>
									</div>
								</Col>
								<Col xs="12" className="py-3">
									<label>
										<span className="text-muted">
											Fields show your recipients where to
											sign or enter information.
										</span>
									</label>
									<img src={addingFieldsImg} />
								</Col>
							</Row>
							<Button id="addfieldsbtn" className="close-btn">
								{' '}
								Add Fields
							</Button>

							<Button
								id="sendwithoutfieldsbtn"
								className="close-btn">
								{' '}
								Send without fields
							</Button>
						</div>
					</div>
				</div>

				<Row className="mb-lg-3">
					<Col lg={12} id="editortoolbar" className="editortoolbar">
						<Row>
							<Col lg="2">
								<select
									id="recipientselect"
									className="form-control selectpicker form-control-sm"
								/>
							</Col>
							<Col lg="8">
								<button
									id="zoominbtn"
									color="neutral"
									className="toolzoom">
									<i className="material-icons">zoom_in</i>
								</button>
								<button
									id="zoomoutbtn"
									color="neutral"
									className="toolzoom">
									<i className="material-icons">zoom_out</i>
								</button>
								<button
									id="downloaddocbtn"
									color="neutral"
									className="toolzoom">
									<i className="material-icons">get_app</i>
								</button>
								<button
									id="printbtn"
									color="neutral"
									className="toolzoom">
									<i className="material-icons">print</i>
								</button>
							</Col>
							<Col lg="2" className="shortcut-preview-button-container">
								<div className="btn-group">
									{
										!isSignMode() && (
											<button onClick={this.toggleShortcutModal} className="btn btn-primary">Shortcut</button>
										)
									}
									<button className="btn" onClick={this.togglePreview}>
										<i className="ni ni-tablet-button" />
									</button>
								</div>
							</Col>
						</Row>
					</Col>
				</Row>

				<Row>
					<Col lg="2" id="fieldsleftbar">
						<div id="toolbar" className="toolbar">
							<div className="divider" id="fieldscolumn">
								<div className="col my-3 p-2">
									<h6 className="text-uppercase text-black ls-1 mb-1 float-left">
										Fields
									</h6>
								</div>
								<hr className="my-1" />
							</div>
							<button
								id="signaturebtn"
								color="neutral"
								className="tool dragabbleItem">
								<i className="material-icons">gesture</i>
								Signature
							</button>
							<button
								id="datebtn"
								color="neutral"
								className="tool">
								<i className="material-icons">today</i>Date
							</button>
							<button
								id="textbtn"
								color="neutral"
								className="tool">
								<i className=" material-icons">text_fields</i>
								Text
							</button>
							<button
								id="initialbtn"
								color="neutral"
								className="tool dragabbleItem">
								<i className="material-icons">text_format</i>
								Initial
							</button>
							<button
								id="namebtn"
								color="neutral"
								className="tool">
								<i className=" material-icons">person</i>Name
							</button>
							<button
								id="companybtn"
								color="neutral"
								className="tool">
								<i className=" material-icons">apartment</i>
								Company
							</button>
							<button
								id="titlebtn"
								color="neutral"
								className="tool">
								<i className=" material-icons">work</i>Title
							</button>

							<button
								id="clearbtn"
								color="neutral"
								className="tool">
								<i className="material-icons">clear</i>Clear
							</button>
						</div>
					</Col>

					<Col lg="8" id="pdfcol">
						<Row className="justify-content-md-center">
							<Col lg="12" />
						</Row>
						<div
							id="container"
							style={{
								height: '550px',
							}}>
							<div id="pdf-container">
								<Button
									id="movecursorbtn"
									className="m-2 float-left px-4"
									style={{
										zIndex: '2',
									}}
									color="primary"
									type="button">
									Begin
								</Button>
							</div>
						</div>

						<div lg="12" className={`py-3 ${isSignMode() ? 'd-none' : ''}`}>
							<Button
								id="backbtn"
								className="m-2 float-left px-4"
								color="primary"
								type="button">
								Back
							</Button>
							<Button
								id="onlysignerfinishbtn"
								className="m-2 float-left px-4"
								color="primary"
								type="button">
								Finish
							</Button>
							<span
								id="emailbtncontainer"
								style={{ display: 'block' }}>
								<Button
									id="sendemailbtn"
									className="m-2 float-right px-4"
									color="primary"
									type="button">
									Next
								</Button>
							</span>
						</div>

						<SignManager
							defaultName={defaultName}
							defaultInitial={defaultInitial}
							title={`Set Your ${
								signType === 'initial' ? 'Initial' : 'Signature'
								}`}
							visible={showSignModal}
							onSave={this.saveSign}
							onClose={this.toggleSignModal}
						/>
					</Col>
					<Col lg="2" id="fieldsrightbar">
						<div
							id="recipientsbar"
							className="recipientsbar bg-light justify-content-start">
							<Row id="formattingdiv">
								<Col lg="12">
									<div className="divider">
										<div className="col my-3 p-2">
											<h6 className="text-uppercase text-black ls-1 mb-1 float-left">
												Formatting
											</h6>
										</div>
										<hr className="my-1" />
									</div>
									<FormGroup className="my-1 mt-3">
										<div>
											<span
												id="formattingrecipientname"
												className="emaillabelspan py-2"
											/>
										</div>
									</FormGroup>
									<FormGroup className="my-1 mt-3">
										<div
											id="checkdiv"
											className="custom-control custom-checkbox  mx-1">
											<input
												className="custom-control-input"
												id="requiredcheck"
												defaultChecked
												type="checkbox"
											/>
											<label
												className="custom-control-label"
												htmlFor="requiredcheck">
												Required Field
											</label>
										</div>
									</FormGroup>
									<FormGroup className="my-1">
										<span className="emaillabelspan py-2">
											<strong>Scale %</strong>
										</span>
										<Input
											id="input-scale-value"
											min="10"
											max="100"
											type="number"
											defaultValue="100"
										/>
									</FormGroup>
									<FormGroup className="my-1">
										<span className="emaillabelspan py-2">
											<strong>Pixels from Left</strong>
										</span>
										<Input
											id="input-pixels-left"
											type="number"
										/>
									</FormGroup>
									<FormGroup className="my-1">
										<span className="emaillabelspan py-2">
											<strong>Pixels from top</strong>
										</span>
										<Input
											id="input-pixels-top"
											type="number"
										/>
									</FormGroup>
									<FormGroup className="my-1" id="fontdiv">
										<span className="emaillabelspan py-2">
											<strong>Font Type</strong>
										</span>
										<select
											id="fontselect"
											className="form-control  form-control-md"
										/>
										<Row>
											<button
												id="boldbtn"
												color="neutral"
												className="tool inline">
												<i className="material-icons">
													format_bold
												</i>
											</button>
											<button
												id="italicbtn"
												color="neutral"
												className="tool inline">
												<i className="material-icons">
													format_italic
												</i>
											</button>
											<button
												id="underlinebtn"
												color="neutral"
												className="tool inline">
												<i className="material-icons">
													format_underlined
												</i>
											</button>
										</Row>
									</FormGroup>
									<FormGroup className="my-1">
										<Button
											id="deletebtn"
											color="primary"
											className="fullwidth">
											Delete
										</Button>
									</FormGroup>
								</Col>
							</Row>

							<div id="thumb-container">
								<div id="thumb-pdf-container" />
								<div id="thumb-toolbar" />
							</div>
						</div>
					</Col>
				</Row>

				<ShortcutKeyList action={this.proceedShortcut} />
			</div>
		);
	}
}

export default PDFAnnotate;
