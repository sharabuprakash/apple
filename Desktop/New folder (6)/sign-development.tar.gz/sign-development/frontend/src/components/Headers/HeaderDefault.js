import React from 'react';

class HeaderDefault extends React.Component {
	render() {
		return (
			<>
				<div
					className="header bg-gradient-warning pb-8 pt-8"
					style={{
						minHeight: '100px',
					}}
				/>
			</>
		);
	}
}

export default HeaderDefault;
