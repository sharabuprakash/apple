var DataVar = {
	DataPath: '',
	DataURI: '',
	DocName: 'default',
	RecipientArray: [],
	OnlySigner: false,
	SignOrder: false,
	Objects: [],
	Backgrounds: []
};

export default DataVar;
