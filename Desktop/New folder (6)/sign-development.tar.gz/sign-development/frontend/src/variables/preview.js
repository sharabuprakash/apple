var PreviewData = {
	DataPath: '',
	DataURI: '',
	Data: [],
};

export default PreviewData;
