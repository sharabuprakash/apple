var TemplateDataVar = {
	TemplateDataPath: '',
	TemplateDataURI: '',
	TemplateDocName: 'default',
	TemplateRecipientArray: [],
	TemplateID: '',
	TemplateRecipientCount: 0,
	TemplateUserID: '',
};

export default TemplateDataVar;
