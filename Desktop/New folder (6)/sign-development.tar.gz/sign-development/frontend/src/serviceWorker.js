export function removeExistingServiceWorker() {
    if (typeof navigator.serviceWorker != "undefined") {
        navigator.serviceWorker.getRegistrations()
            .then(function(registrations) {
                for(let registration of registrations) {
                    registration.unregister()
                }
            })
    }
}
