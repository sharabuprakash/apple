import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
import {removeExistingServiceWorker} from './serviceWorker'

import {GoogleReCaptchaProvider} from 'react-google-recaptcha-v3';

ReactDOM.render(
	<GoogleReCaptchaProvider
		reCaptchaKey="6LcPcuwUAAAAAL2ebX2lgNSUH8uzqnMDXFTr06wT"
		language="[optional_language]">
		<App />
	</GoogleReCaptchaProvider>,
	document.getElementById('root'),
);

removeExistingServiceWorker()
