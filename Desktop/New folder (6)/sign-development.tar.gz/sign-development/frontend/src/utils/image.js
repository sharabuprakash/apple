function toInt32(bytes) {
	return (bytes[0] << 24) | (bytes[1] << 16) | (bytes[2] << 8) | bytes[3];
}

function getDimensions(data) {
	return {
		width: toInt32(data.slice(16, 20)),
		height: toInt32(data.slice(20, 24)),
	};
}

var base64Characters =
	'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';

function base64Decode(data) {
	var result = [];
	var current = 0;

	for (var i = 0, c; (c = data.charAt(i)); i++) {
		if (c === '=') {
			if (
				i !== data.length - 1 &&
				(i !== data.length - 2 || data.charAt(i + 1) !== '=')
			) {
				throw new SyntaxError('Unexpected padding character.');
			}

			break;
		}

		var index = base64Characters.indexOf(c);

		if (index === -1) {
			throw new SyntaxError('Invalid Base64 character.');
		}

		current = (current << 6) | index;

		if (i % 4 === 3) {
			result.push(current >> 16, (current & 0xff00) >> 8, current & 0xff);
			current = 0;
		}
	}

	if (i % 4 === 1) {
		throw new SyntaxError('Invalid length for a Base64 string.');
	}

	if (i % 4 === 2) {
		result.push(current >> 4);
	} else if (i % 4 === 3) {
		current <<= 6;
		result.push(current >> 16, (current & 0xff00) >> 8);
	}

	return result;
}

export function getPngDimensions(dataUri) {
	if (dataUri.substring(0, 22) !== 'data:image/png;base64,') {
		throw new Error('Unsupported data URI format');
	}

	// 32 base64 characters encode the necessary 24 bytes
	return getDimensions(base64Decode(dataUri.substr(22, 32)));
}

export async function resizeImage(img, width = null, height = null, alias = false) {
	if (!width && !height) {
		throw new Error('Please set width or height');
	}
	const oldDimension = getPngDimensions(img);

	if (!width && height) {
		const ratio = Math.abs(height / oldDimension.height);
		width = oldDimension.width * ratio;
	}

	if (!height && width) {
		const ratio = Math.abs(width / oldDimension.width);
		height = oldDimension.height * ratio;
	}

	var imgDom = document.createElement('img');
	imgDom.src = img;

	const result = await new Promise((resolve) => {
		imgDom.onload = function () {
			var canvas = document.createElement('canvas'),
				ctx = canvas.getContext('2d');

			canvas.width = width;
			canvas.height = height;

			ctx.drawImage(this, 0, 0, width, height);
			resolve(canvas.toDataURL());
		};
	});

	return result;
}

export function convertBase64ToImage(base64) {
	return new Promise(resolve => {
		var image = new Image();
		image.onload = function() {
			resolve(image);
		};
		image.src = base64;;
	})
}


export const mergeImages = (sources = [], options = {}) => new Promise(async resolve => {
    options = Object.assign({}, {
        format: 'image/jpeg',
        quality: 1,
        width: undefined,
        height: undefined,
        Canvas: undefined,
        crossOrigin: undefined
    }, options);

    // Setup browser/Node.js specific variables
    const canvas = options.Canvas || window.document.createElement('canvas');
    const Image = options.Image || window.Image;

    // Load sources
    const images = sources.map(source => new Promise( (r, reject) => {
        // Convert sources to objects
        if (source.constructor.name !== 'Object') {
            source = { src: source };
        }

        // Resolve source and img when loaded
        const img = new Image();
        img.crossOrigin = options.crossOrigin;
        img.onerror = () => reject(new Error('Couldn\'t load image'));
        img.onload = () => r(Object.assign({}, source, { img }));
        img.src = source.src;
    }));

    // Get canvas context
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    let imagesObj = await Promise.all(images);

    let draws = imagesObj.map(image => {
        return new Promise(async r => {
            await ctx.drawImage(image.img, image.x || 0, image.y || 0);
            r();
        })
    });

    await Promise.all(draws);

    let result = await canvas.toDataURL(options.format, options.quality);

    resolve(result);
});
