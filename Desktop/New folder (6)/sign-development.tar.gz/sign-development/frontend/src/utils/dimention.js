export function resizeDimention(oldWidth, oldHeight , newWidth = 0, newHeight = 0) {
    if (!oldWidth && !oldHeight) {
        throw new Error('Please set width or height');
    }

    if (!newWidth && newHeight) {
        const ratio = Math.abs(newHeight / oldHeight);
        newWidth = oldWidth * ratio;
    }

    if (!newHeight && newWidth) {
        const ratio = Math.abs(newWidth / oldWidth);
        newHeight = oldHeight * ratio;
    }

    return {
        height: newHeight,
        width: newWidth
    }
}
