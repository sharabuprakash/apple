# Pappaya Sign

An e-Signature application

## Requirements

Install Mongo locally.

## Install

1. Clone repo
2. Run `cd frontend && npm install`
3. Run `cd backend && npm install`

## Run for Development

-   Run `cd frontend && npm start` to start the live updating react development build.
-   Run `cd backend && npm start` to start the node server.

## Build for Production

Run ./deploy.sh to run deployment script
